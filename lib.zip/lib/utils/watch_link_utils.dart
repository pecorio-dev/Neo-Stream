import 'dart:io';

import '../models/content.dart';

class WatchLinkUtils {
  static const List<_DomainPriority> _domainPriorities = [
    _DomainPriority(patterns: ['m3u8', '.mp4'], score: 260),
    _DomainPriority(patterns: ['hlsplay'], score: 240),
    _DomainPriority(patterns: ['uqload'], score: 232),
    _DomainPriority(patterns: ['vidzy'], score: 228),
    _DomainPriority(patterns: ['voe'], score: 224),
    _DomainPriority(patterns: ['filemoon'], score: 220),
    _DomainPriority(patterns: ['vidmoly'], score: 216),
    _DomainPriority(patterns: ['vidoza', 'vido.lol'], score: 212),
    _DomainPriority(patterns: ['streamdav'], score: 208),
    _DomainPriority(patterns: ['younetu', 'netu'], score: 204),
    _DomainPriority(patterns: ['uptostream'], score: 200),
    _DomainPriority(patterns: ['evoload'], score: 196),
    _DomainPriority(patterns: ['sbfull'], score: 192),
    _DomainPriority(patterns: ['mixdrop', 'mxdrop'], score: 188),
    _DomainPriority(
      patterns: [
        'upvid',
        'onlystream',
        'streamtape',
        'streamlare',
        'streamango',
        'mystream',
        'viewsb',
        'videovard',
        'verystream',
        'fsvid',
        'fsimg',
        'bigwarp',
      ],
      score: 186,
    ),
    _DomainPriority(patterns: ['gounlimited'], score: 184),
    _DomainPriority(patterns: ['vidlox'], score: 180),
    _DomainPriority(patterns: ['jetload'], score: 176),
    _DomainPriority(
      patterns: ['dood', 'dsvplay', 'do7go', 'luluvdo', 'bysewihe', '96ar'],
      score: 174,
    ),
    _DomainPriority(
      patterns: ['kakaflix', 'kokoflix', 'flixeo', 'sequoia'],
      score: 170,
    ),
    _DomainPriority(patterns: ['multiup'], score: 166),
    _DomainPriority(patterns: ['uptobox', 'drive.google'], score: 150),
    _DomainPriority(
      patterns: [
        'lancewhosedifficult',
        'bysebuho',
        'sandratableother',
        'maxfinishseveral',
        'areup99',
      ],
      score: 158,
    ),
  ];

  static List<WatchLink> prioritize(
    List<WatchLink> links, {
    String? preferredLanguage,
  }) {
    final ranked = links
        .where((link) => link.url.trim().isNotEmpty)
        .toList(growable: true);

    ranked.sort(
      (left, right) => score(
        right,
        preferredLanguage: preferredLanguage,
      ).compareTo(score(left, preferredLanguage: preferredLanguage)),
    );

    final seen = <String>{};
    return ranked.where((link) => seen.add(sourceSignature(link))).toList();
  }

  static List<String> sortLanguages(Iterable<String> languages) {
    final normalized = languages
        .map((language) => language.trim().toLowerCase())
        .where((language) => language.isNotEmpty)
        .toSet()
        .toList(growable: true);

    const order = <String, int>{'vf': 0, 'vostfr': 1, 'unknown': 2};

    normalized.sort(
      (left, right) => (order[left] ?? 99).compareTo(order[right] ?? 99),
    );
    return normalized;
  }

  static String defaultLanguage(Iterable<String> languages) {
    final sorted = sortLanguages(
      languages.where((language) => language != 'unknown'),
    );
    if (sorted.contains('vf')) {
      return 'vf';
    }
    if (sorted.contains('vostfr')) {
      return 'vostfr';
    }
    return sorted.isNotEmpty ? sorted.first : 'vf';
  }

  static String labelForLanguage(String languageCode) {
    switch (languageCode.trim().toLowerCase()) {
      case 'vf':
        return 'VF';
      case 'vostfr':
        return 'VOSTFR';
      default:
        return 'Auto';
    }
  }

  static int recommendedParallelism() {
    final cores = Platform.numberOfProcessors;
    if (cores <= 4) {
      return 1;
    }
    if (cores <= 8) {
      return 2;
    }
    return 3;
  }

  static int score(WatchLink link, {String? preferredLanguage}) {
    final languageCode = link.languageCode;
    final normalizedPreferred = preferredLanguage?.trim().toLowerCase();
    var total = _domainScore(link) + _serverHintScore(link);

    if (normalizedPreferred != null && normalizedPreferred.isNotEmpty) {
      if (languageCode == normalizedPreferred) {
        total += 90;
      } else if (languageCode == 'unknown') {
        total += 30;
      }
    }

    if (link.url.contains('.m3u8') || link.url.contains('.mp4')) {
      total += 120;
    }

    return total;
  }

  static String sourceSignature(WatchLink link) {
    return '${_normalizeSource(link)}|${link.server.toLowerCase()}|${link.url.toLowerCase()}';
  }

  static String sourceLabel(WatchLink link) {
    final domain = _extractDomain(link);
    if (domain.isNotEmpty) {
      return domain;
    }
    return link.serverName;
  }

  static int _domainScore(WatchLink link) {
    final source = _normalizeSource(link);
    if (source.contains('https://https://')) {
      return 12;
    }
    for (final priority in _domainPriorities) {
      if (priority.matches(source)) {
        return priority.score;
      }
    }
    return 120;
  }

  static int _serverHintScore(WatchLink link) {
    final server = link.server.toLowerCase();
    if (server.contains('multi') || server.contains('embed')) {
      return 6;
    }
    return 0;
  }

  static String _normalizeSource(WatchLink link) {
    return '${_extractDomain(link)} ${link.server.toLowerCase()} ${link.url.toLowerCase()}';
  }

  static String _extractDomain(WatchLink link) {
    if (link.domain.trim().isNotEmpty) {
      return link.domain.trim().toLowerCase();
    }
    return Uri.tryParse(link.url)?.host.toLowerCase() ?? '';
  }
}

class _DomainPriority {
  final List<String> patterns;
  final int score;

  const _DomainPriority({required this.patterns, required this.score});

  bool matches(String source) {
    for (final pattern in patterns) {
      if (source.contains(pattern)) {
        return true;
      }
    }
    return false;
  }
}
