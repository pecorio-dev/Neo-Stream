import 'dart:ui';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../config/theme.dart';
import '../models/content.dart';

enum CardVariant {
  standard,
  dailyTop,
  recommendation,
  continueWatching,
  search,
}

class ContentCard extends StatefulWidget {
  final Content content;
  final CardVariant variant;
  final int index;
  final VoidCallback? onTap;

  const ContentCard({
    super.key,
    required this.content,
    this.variant = CardVariant.standard,
    this.index = 0,
    this.onTap,
  });

  @override
  State<ContentCard> createState() => _ContentCardState();
}

class _ContentCardState extends State<ContentCard> {
  bool _isFocused = false;

  @override
  Widget build(BuildContext context) {
    return Focus(
      onFocusChange: (focused) {
        if (_isFocused == focused) {
          return;
        }
        setState(() => _isFocused = focused);
      },
      child: Semantics(
        button: true,
        label:
            '${widget.content.isSerie ? 'Série' : 'Film'}: ${widget.content.displayTitle}',
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: widget.onTap,
            canRequestFocus: true, // IMPORTANT POUR LA TV
            autofocus:
                widget.index == 0 &&
                widget.variant ==
                    CardVariant
                        .standard, // Auto-focus sur le premier element (optionnel)
            focusColor: NeoTheme.primaryRed.withValues(
              alpha: 0.3,
            ), // Couleur visible pour le focus TV
            borderRadius: BorderRadius.circular(NeoTheme.radiusMd),
            splashColor: NeoTheme.primaryRed.withValues(alpha: 0.1),
            highlightColor: NeoTheme.primaryRed.withValues(alpha: 0.05),
            child: AnimatedScale(
              scale: (_isFocused && NeoTheme.isTV(context))
                  ? 1.05
                  : 1, // Effet de zoom plus prononcé pour la TV uniquement
              duration: NeoTheme.durationFast,
              curve: NeoTheme.smoothOut,
              child: AnimatedContainer(
                duration: NeoTheme.durationFast,
                curve: NeoTheme.smoothOut,
                decoration: _isFocused && NeoTheme.isTV(context)
                    ? BoxDecoration(
                        borderRadius: BorderRadius.circular(NeoTheme.radiusMd),
                        border: Border.all(
                          color: NeoTheme
                              .primaryRed, // Rouge au lieu de blanc pour coller aux 2 couleurs dominantes
                          width: 4, // Plus epais pour etre encore plus visible
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: NeoTheme.primaryRed.withValues(
                              alpha: 0.6,
                            ), // Ombre plus forte
                            blurRadius: 24,
                            spreadRadius: 4,
                          ),
                        ],
                      )
                    : null,
                child: _buildVariant(context),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildVariant(BuildContext context) {
    switch (widget.variant) {
      case CardVariant.dailyTop:
        return _buildDailyTopCard(context);
      case CardVariant.recommendation:
        return _buildRecommendationCard(context);
      case CardVariant.continueWatching:
        return _buildContinueWatchingCard(context);
      case CardVariant.search:
        return _buildSearchCard(context);
      case CardVariant.standard:
        return _buildStandardCard(context);
    }
  }

  Widget _buildStandardCard(BuildContext context) {
    final compact = MediaQuery.of(context).size.width < 430;
    final footerPills = _buildFooterPills(context, limit: compact ? 2 : 3);

    return Container(
      width: NeoTheme.cardWidth(context),
      decoration: _isFocused
          ? NeoTheme.cardFocusedDecoration
          : NeoTheme.cardDecoration,
      clipBehavior: Clip.antiAlias,
      child: Stack(
        fit: StackFit.expand,
        children: [
          _buildPoster(widget.content.fullPosterUrl),
          const DecoratedBox(
            decoration: BoxDecoration(gradient: NeoTheme.cardOverlayGradient),
          ),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.fromLTRB(10, 10, 10, 20),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xCC050508),
                    Color(0x7A050508),
                    Colors.transparent,
                  ],
                  stops: [0.0, 0.55, 1.0],
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: [
                        _buildTypeBadge(),
                        if (widget.content.isPremiumContent)
                          _buildInfoPill(
                            context,
                            'Premium',
                            color: NeoTheme.prestigeGold,
                          ),
                      ],
                    ),
                  ),
                  if (widget.content.rating > 0) ...[
                    const SizedBox(width: 8),
                    _buildRatingBadge(
                      widget.content.rating,
                      compact: true,
                      emphasized: true,
                    ),
                  ],
                ],
              ),
            ),
          ),
          if (widget.content.progressPercent != null &&
              widget.content.progressPercent! > 0)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: _buildProgressBar(widget.content.progressPercent!),
            ),
          Positioned(
            left: 12,
            right: 12,
            bottom: 12,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: NeoTheme.bgBase.withValues(alpha: 0.85),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: NeoTheme.bgBorder.withValues(alpha: 0.35),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.3),
                    blurRadius: 16,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (widget.content.languageTag.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: _buildInfoPill(
                        context,
                        widget.content.languageTag,
                        color: NeoTheme.primaryRed,
                      ),
                    ),
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerLeft,
                    child: Text(
                      widget.content.displayTitle,
                      maxLines: 1,
                      style: NeoTheme.labelLarge(
                        context,
                      ).copyWith(fontWeight: FontWeight.w800, height: 1.15),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    _metaLine(),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: NeoTheme.labelSmall(
                      context,
                    ).copyWith(color: NeoTheme.textSecondary),
                  ),
                  if (footerPills.isNotEmpty) ...[
                    const SizedBox(height: 9),
                    Wrap(spacing: 6, runSpacing: 6, children: footerPills),
                  ],
                  if (!compact &&
                      widget.content.description != null &&
                      widget.content.description!.trim().isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(
                      widget.content.description!,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: NeoTheme.bodySmall(
                        context,
                      ).copyWith(color: NeoTheme.textTertiary, height: 1.25),
                    ),
                  ],
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(
                        Icons.play_circle_fill_rounded,
                        size: 15,
                        color: _isFocused
                            ? NeoTheme.primaryRed
                            : NeoTheme.textSecondary,
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          widget.content.isSerie
                              ? 'Ouvrir la fiche serie'
                              : 'Ouvrir la fiche film',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: NeoTheme.labelSmall(context).copyWith(
                            color: _isFocused
                                ? NeoTheme.primaryRed
                                : NeoTheme.textSecondary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          if (_isFocused)
            Positioned.fill(
              child: Container(
                color: Colors.black.withValues(alpha: 0.18),
                child: const Center(
                  child: Icon(
                    Icons.play_circle_fill_rounded,
                    color: Colors.white,
                    size: 54,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildDailyTopCard(BuildContext context) {
    return SizedBox(
      width: NeoTheme.cardWidth(context) + 42,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          SizedBox(
            width: 46,
            child: Text(
              '${widget.content.rank ?? (widget.index + 1)}',
              style: NeoTheme.displayLarge(context).copyWith(
                fontSize: 58,
                foreground: Paint()
                  ..shader = NeoTheme.heroGradient.createShader(
                    const Rect.fromLTWH(0, 0, 64, 72),
                  ),
              ),
            ),
          ),
          Expanded(child: _buildStandardCard(context)),
        ],
      ),
    );
  }

  Widget _buildRecommendationCard(BuildContext context) {
    final footerPills = _buildFooterPills(context, limit: 2);

    return Container(
      width: NeoTheme.cardWidth(context),
      decoration: _isFocused
          ? NeoTheme.cardFocusedDecoration
          : NeoTheme.cardDecoration,
      clipBehavior: Clip.antiAlias,
      child: Stack(
        fit: StackFit.expand,
        children: [
          _buildPoster(widget.content.fullPosterUrl),
          const DecoratedBox(
            decoration: BoxDecoration(gradient: NeoTheme.cardOverlayGradient),
          ),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.fromLTRB(10, 10, 10, 20),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xCC050508),
                    Color(0x7A050508),
                    Colors.transparent,
                  ],
                  stops: [0.0, 0.55, 1.0],
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (widget.content.matchPercent != null)
                    Expanded(
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: _buildInfoPill(
                          context,
                          '${widget.content.matchPercent}% pour vous',
                          color: NeoTheme.successGreen,
                        ),
                      ),
                    )
                  else
                    const Spacer(),
                  if (widget.content.rating > 0) ...[
                    const SizedBox(width: 8),
                    _buildRatingBadge(widget.content.rating, emphasized: true),
                  ],
                ],
              ),
            ),
          ),
          Positioned(
            left: 12,
            right: 12,
            bottom: 12,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: NeoTheme.bgBase.withValues(alpha: 0.85),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: NeoTheme.bgBorder.withValues(alpha: 0.35),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.3),
                    blurRadius: 16,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (widget.content.languageTag.isNotEmpty) ...[
                    _buildInfoPill(
                      context,
                      widget.content.languageTag,
                      color: NeoTheme.primaryRed,
                    ),
                    const SizedBox(height: 8),
                  ],
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerLeft,
                    child: Text(
                      widget.content.displayTitle,
                      maxLines: 1,
                      style: NeoTheme.labelLarge(
                        context,
                      ).copyWith(fontWeight: FontWeight.w800, height: 1.15),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    widget
                        .content
                        .typeLabel, // Simplified to just show type label instead of duplicating genre
                    style: NeoTheme.labelSmall(
                      context,
                    ).copyWith(color: NeoTheme.textSecondary),
                  ),
                  if (footerPills.isNotEmpty) ...[
                    const SizedBox(height: 9),
                    Wrap(spacing: 6, runSpacing: 6, children: footerPills),
                  ],
                  if (widget.content.description != null &&
                      widget.content.description!.trim().isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(
                      widget.content.description!,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: NeoTheme.bodySmall(
                        context,
                      ).copyWith(color: NeoTheme.textTertiary),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContinueWatchingCard(BuildContext context) {
    return Container(
      width: NeoTheme.isTV(context) ? 372 : 318,
      decoration: _isFocused
          ? NeoTheme.cardFocusedDecoration
          : NeoTheme.cardDecoration,
      clipBehavior: Clip.antiAlias,
      child: Row(
        children: [
          SizedBox(
            width: 122,
            height: 200, // Added fixed height to prevent infinite height error
            child: Stack(
              fit: StackFit.expand,
              children: [
                _buildPoster(widget.content.fullPosterUrl),
                const DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.transparent, Color(0xC0050508)],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    widget.content.displayTitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: NeoTheme.titleMedium(context),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    widget.content.currentEpisodeId ??
                        (widget.content.isSerie
                            ? 'Serie en cours'
                            : 'Film en cours'),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: NeoTheme.bodySmall(context),
                  ),
                  const SizedBox(height: 10),
                  if (widget.content.progressPercent != null)
                    _buildProgressBar(widget.content.progressPercent!),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: _buildFooterPills(context, limit: 3),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      const Icon(
                        Icons.play_circle_fill_rounded,
                        size: 18,
                        color: NeoTheme.primaryRed,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        'Reprendre maintenant',
                        style: NeoTheme.labelMedium(
                          context,
                        ).copyWith(color: NeoTheme.primaryRed),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchCard(BuildContext context) {
    final showDescription = MediaQuery.of(context).size.width >= 900;

    return Container(
      decoration: BoxDecoration(
        color: NeoTheme.bgElevated,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: NeoTheme.bgBorder.withValues(alpha: 0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120, // Slightly smaller width
            height: 180, // Fixed height is crucial here
            child: ClipRRect(
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(11),
                bottomLeft: Radius.circular(11),
              ),
              child: _buildPoster(widget.content.fullPosterUrl),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min, // Important for row layout
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Text(
                          widget.content.displayTitle,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: NeoTheme.titleMedium(
                            context,
                          ).copyWith(fontWeight: FontWeight.w800),
                        ),
                      ),
                      if (widget.content.rating > 0) ...[
                        const SizedBox(width: 8),
                        _buildRatingBadge(
                          widget.content.rating,
                          compact: false,
                          emphasized: true,
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _buildTypeBadge(),
                      if (widget.content.languageTag.isNotEmpty)
                        _buildInfoPill(
                          context,
                          widget.content.languageTag,
                          color: NeoTheme.primaryRed,
                        ),
                      if (widget.content.releaseDate != null)
                        _buildInfoPill(
                          context,
                          '${widget.content.releaseDate}',
                        ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    widget.content.genresText,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: NeoTheme.bodySmall(
                      context,
                    ).copyWith(color: NeoTheme.textSecondary),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: _buildFooterPills(context, limit: 2),
                  ),
                  const SizedBox(height: 10),
                  if (showDescription &&
                      widget.content.description != null &&
                      widget.content.description!.trim().isNotEmpty)
                    Text(
                      widget.content.description!,
                      maxLines: NeoTheme.isTV(context) ? 3 : 2,
                      overflow: TextOverflow.ellipsis,
                      style: NeoTheme.bodySmall(
                        context,
                      ).copyWith(color: NeoTheme.textSecondary),
                    ),
                  if (showDescription &&
                      widget.content.description != null &&
                      widget.content.description!.trim().isNotEmpty)
                    const SizedBox(height: 8),
                  // Removed the redundant text display of genre here since it's already in the pills
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPoster(String url) {
    if (url.isEmpty) {
      return Container(
        color: NeoTheme.bgElevated,
        child: const Center(
          child: Icon(
            Icons.movie_creation_outlined,
            color: NeoTheme.textDisabled,
          ),
        ),
      );
    }

    return CachedNetworkImage(
      imageUrl: url,
      fit: BoxFit.cover,
      placeholder: (_, _) => Shimmer.fromColors(
        baseColor: NeoTheme.bgElevated,
        highlightColor: NeoTheme.bgOverlay,
        child: Container(color: NeoTheme.bgElevated),
      ),
      errorWidget: (_, _, _) => Container(
        color: NeoTheme.bgElevated,
        child: const Center(
          child: Icon(
            Icons.broken_image_outlined,
            color: NeoTheme.textDisabled,
          ),
        ),
      ),
    );
  }

  Widget _buildTypeBadge() {
    final color = widget.content.isSerie
        ? NeoTheme.textPrimary
        : NeoTheme.primaryRed;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.22),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        widget.content.typeLabel,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  Widget _buildRatingBadge(
    double rating, {
    bool compact = false,
    bool emphasized = false,
  }) {
    final size = compact ? 32.0 : 38.0;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: const Color(0xE61C1605),
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.25),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          SizedBox(
            width: size,
            height: size,
            child: CircularProgressIndicator(
              value: rating / 10.0,
              strokeWidth: compact ? 2.5 : 3.0,
              backgroundColor: NeoTheme.prestigeGold.withValues(alpha: 0.15),
              valueColor: const AlwaysStoppedAnimation<Color>(
                NeoTheme.prestigeGold,
              ),
            ),
          ),
          Text(
            rating.toStringAsFixed(1),
            style: TextStyle(
              color: NeoTheme.prestigeGold,
              fontSize: compact ? 10 : 12,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoPill(BuildContext context, String label, {Color? color}) {
    final accent = color ?? NeoTheme.bgBorder;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color != null
            ? accent.withValues(alpha: 0.22)
            : NeoTheme.bgSurface.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(
          color: color != null
              ? accent.withValues(alpha: 0.42)
              : NeoTheme.bgBorder.withValues(alpha: 0.32),
          width: 0.8,
        ),
      ),
      child: Text(
        label,
        style: NeoTheme.labelSmall(context).copyWith(
          color: color ?? NeoTheme.textPrimary,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  Widget _buildProgressBar(double percent) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(999),
      child: LinearProgressIndicator(
        value: (percent / 100).clamp(0.0, 1.0),
        backgroundColor: NeoTheme.bgBorder.withValues(alpha: 0.28),
        minHeight: 4,
        valueColor: const AlwaysStoppedAnimation<Color>(NeoTheme.primaryRed),
      ),
    );
  }

  String _metaLine() {
    final parts = <String>[];
    if (widget.content.releaseDate != null) {
      parts.add('${widget.content.releaseDate}');
    }
    // Retiré le mainGenre de la _metaLine car il est déjà dans les pills juste en dessous
    if (parts.isEmpty) {
      parts.add(widget.content.typeLabel);
    }
    return parts.join(' / ');
  }

  List<Widget> _buildFooterPills(BuildContext context, {int limit = 3}) {
    final pills = <Widget>[];

    if (widget.content.isSerie && widget.content.seasonCount > 0) {
      pills.add(
        _buildInfoPill(
          context,
          widget.content.seasonCount > 1
              ? '${widget.content.seasonCount} saisons'
              : '1 saison',
        ),
      );
    }

    if (widget.content.episodeCount > 0) {
      pills.add(_buildInfoPill(context, '${widget.content.episodeCount} ep'));
    }

    if (widget.content.mainGenre.isNotEmpty) {
      pills.add(
        _buildInfoPill(
          context,
          widget.content.mainGenre,
          // Utilisation du blanc/gris comme demandé au lieu de la couleur spécifique au genre
          color: NeoTheme.textPrimary,
        ),
      );
    }

    if (widget.content.matchPercent != null) {
      final showMatchInFooter = widget.variant != CardVariant.recommendation;
      if (showMatchInFooter) {
        pills.add(
          _buildInfoPill(
            context,
            '${widget.content.matchPercent}% match',
            color: NeoTheme.primaryRed,
          ),
        );
      }
    }

    if ((widget.content.todayViews ?? 0) > 0) {
      pills.add(
        _buildInfoPill(
          context,
          '${widget.content.todayViews} vues',
          color: NeoTheme.textPrimary,
        ),
      );
    }

    return pills.take(limit).toList();
  }
}
