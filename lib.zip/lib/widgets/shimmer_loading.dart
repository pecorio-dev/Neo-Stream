import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../config/theme.dart';

class ShimmerHomeLoading extends StatelessWidget {
  const ShimmerHomeLoading({super.key});

  @override
  Widget build(BuildContext context) {
    final heroHeight = NeoTheme.heroHeight(context);
    final horizontalPadding = NeoTheme.screenPadding(context).horizontal / 2;

    return Shimmer.fromColors(
      baseColor: NeoTheme.bgElevated,
      highlightColor: NeoTheme.bgOverlay,
      child: SingleChildScrollView(
        physics: const NeverScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: heroHeight,
              decoration: const BoxDecoration(
                gradient: NeoTheme.auroraGradient,
              ),
            ),
            const SizedBox(height: 28),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
              child: Container(
                height: 54,
                decoration: NeoTheme.panelDecoration(elevated: true),
              ),
            ),
            const SizedBox(height: 18),
            for (var section = 0; section < 4; section++) ...[
              Padding(
                padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
                child: Container(
                  width: 220,
                  height: 26,
                  decoration: NeoTheme.panelDecoration(),
                ),
              ),
              const SizedBox(height: 14),
              SizedBox(
                height: NeoTheme.cardHeight(context),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  physics: const NeverScrollableScrollPhysics(),
                  padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
                  itemCount: 5,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.only(right: 12),
                      child: Container(
                        width: NeoTheme.cardWidth(context),
                        decoration: NeoTheme.cardDecoration,
                      ),
                    );
                  },
                ),
              ),
              SizedBox(height: NeoTheme.sectionGap(context)),
            ],
          ],
        ),
      ),
    );
  }
}
