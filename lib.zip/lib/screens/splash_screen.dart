import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../config/theme.dart';
import '../providers/providers.dart';
import 'login_screen.dart';
import 'home_screen.dart';
import 'profile_picker_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _logoController;
  late AnimationController _lineController;
  late AnimationController _textController;

  late Animation<double> _logoScale;
  late Animation<double> _logoOpacity;
  late Animation<double> _lineWidth;
  late Animation<double> _textOpacity;

  @override
  void initState() {
    super.initState();

    // Logo animation (0-500ms)
    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _logoScale = Tween<double>(begin: 0.7, end: 1.0).animate(
      CurvedAnimation(parent: _logoController, curve: NeoTheme.smoothOut),
    );
    _logoOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _logoController, curve: NeoTheme.smoothOut),
    );

    // Red line animation (500-1000ms)
    _lineController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _lineWidth = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _lineController, curve: NeoTheme.smoothOut),
    );

    // Loading text animation (1000ms+)
    _textController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _textOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _textController, curve: NeoTheme.smoothOut),
    );

    _startAnimations();
  }

  Future<void> _startAnimations() async {
    // Start logo
    _logoController.forward();
    await Future.delayed(const Duration(milliseconds: 500));

    // Start line
    _lineController.forward();
    await Future.delayed(const Duration(milliseconds: 400));

    // Start text
    _textController.forward();

    // Try auto login
    await Future.delayed(const Duration(milliseconds: 300));
    if (!mounted) return;

    final authProvider = context.read<AuthProvider>();
    final success = await authProvider.tryAutoLogin();

    if (!mounted) return;

    // Navigate
    await Future.delayed(const Duration(milliseconds: 500));
    if (!mounted) return;

    Widget destination;
    if (!success && authProvider.hasStoredSession) {
      destination = const HomeScreen();
    } else if (!success) {
      destination = const LoginScreen();
    } else {
      final user = authProvider.user;
      if (user != null && user.premiumActive && !user.isSubAccount) {
        destination = ProfilePickerScreen(mainUser: user);
      } else {
        destination = const HomeScreen();
      }
    }

    Navigator.of(context).pushAndRemoveUntil(
      PageRouteBuilder(
        pageBuilder: (_, _, _) => destination,
        transitionDuration: NeoTheme.durationSplash,
        transitionsBuilder: (_, animation, _, child) =>
            FadeTransition(opacity: animation, child: child),
      ),
      (route) => false,
    );
  }

  @override
  void dispose() {
    _logoController.dispose();
    _lineController.dispose();
    _textController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoTheme.bgBase,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Logo
            AnimatedBuilder(
              animation: _logoController,
              builder: (context, child) => Opacity(
                opacity: _logoOpacity.value,
                child: Transform.scale(
                  scale: _logoScale.value,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'NEO',
                        style: NeoTheme.displayLarge(context).copyWith(
                          color: NeoTheme.primaryRed,
                          fontSize: 42 * NeoTheme.scaleFactor(context),
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'STREAM',
                        style: NeoTheme.displayLarge(context).copyWith(
                          color: NeoTheme.textPrimary,
                          fontSize: 42 * NeoTheme.scaleFactor(context),
                          fontWeight: FontWeight.w300,
                          letterSpacing: 4,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            const SizedBox(height: 12),

            // Red animated line
            AnimatedBuilder(
              animation: _lineController,
              builder: (context, child) => Container(
                height: 3,
                width: 200 * _lineWidth.value,
                decoration: BoxDecoration(
                  gradient: NeoTheme.heroGradient,
                  borderRadius: BorderRadius.circular(2),
                  boxShadow: [
                    BoxShadow(
                      color: NeoTheme.primaryRed.withValues(alpha: 0.5),
                      blurRadius: 12,
                      spreadRadius: 2,
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 32),

            // Loading text
            AnimatedBuilder(
              animation: _textController,
              builder: (context, child) => Opacity(
                opacity: _textOpacity.value,
                child: Text(
                  'Chargement...',
                  style: NeoTheme.bodyMedium(
                    context,
                  ).copyWith(color: NeoTheme.textTertiary, letterSpacing: 2),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
