import 'dart:async';

import 'package:flutter/material.dart';

import '../config/theme.dart';
import '../models/content.dart';
import '../services/api_service.dart';
import '../widgets/content_card.dart';
import '../widgets/section_header.dart';
import 'detail_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final ApiService _api = ApiService();
  final TextEditingController _searchController = TextEditingController();
  Timer? _debounce;
  List<Content> _results = [];
  bool _isLoading = false;
  String _lastQuery = '';
  String _filterType = 'all';
  String? _errorMessage;

  @override
  void dispose() {
    _debounce?.cancel();
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged(String query) {
    _debounce?.cancel();
    setState(() {});

    _debounce = Timer(const Duration(milliseconds: 350), () {
      if (query.trim().length >= 2 && query != _lastQuery) {
        _performSearch(query.trim());
      } else if (query.trim().isEmpty) {
        setState(() {
          _results = [];
          _lastQuery = '';
          _filterType = 'all';
          _errorMessage = null;
        });
      }
    });
  }

  Future<void> _performSearch(String query) async {
    setState(() {
      _isLoading = true;
      _lastQuery = query;
      _filterType = 'all';
      _errorMessage = null;
    });

    try {
      final results = await _api.searchContent(query);
      setState(() {
        _results = results;
        _isLoading = false;
        _errorMessage = null;
      });
    } catch (error) {
      setState(() {
        _results = [];
        _isLoading = false;
        _errorMessage = humanizeApiError(error);
      });
    }
  }

  List<Content> get _filteredResults {
    if (_filterType == 'all') return _results;
    if (_filterType == 'film')
      return _results.where((content) => content.isFilm).toList();
    if (_filterType == 'serie')
      return _results.where((content) => content.isSerie).toList();
    return _results
        .where((content) => content.contentType == _filterType)
        .toList();
  }

  void _navigateToDetail(Content content) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => DetailScreen(contentId: content.id)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filteredResults = _filteredResults;
    final filmCount = _results.where((content) => content.isFilm).length;
    final serieCount = _results.where((content) => content.isSerie).length;
    final useGrid = MediaQuery.of(context).size.width >= 900;

    return Scaffold(
      backgroundColor: NeoTheme.bgBase,
      body: SafeArea(
        top: !NeoTheme.isTV(context),
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(
                NeoTheme.screenPadding(context).left,
                12,
                NeoTheme.screenPadding(context).right,
                0,
              ),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 14,
                ),
                decoration: NeoTheme.panelDecoration(elevated: true),
                child: Row(
                  children: [
                    const Icon(
                      Icons.search_rounded,
                      color: NeoTheme.textSecondary,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextField(
                        controller: _searchController,
                        onChanged: _onSearchChanged,
                        autofocus: !NeoTheme.isTV(context),
                        style: NeoTheme.bodyLarge(
                          context,
                        ).copyWith(color: NeoTheme.textPrimary),
                        decoration: InputDecoration(
                          isDense: true,
                          hintText: 'Titre, genre, acteur, mot-cle...',
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          filled: false,
                          hintStyle: NeoTheme.bodyMedium(
                            context,
                          ).copyWith(color: NeoTheme.textDisabled),
                        ),
                      ),
                    ),
                    if (_searchController.text.isNotEmpty)
                      IconButton(
                        onPressed: () {
                          _searchController.clear();
                          setState(() {
                            _results = [];
                            _lastQuery = '';
                            _filterType = 'all';
                            _errorMessage = null;
                          });
                        },
                        icon: const Icon(Icons.close_rounded),
                        color: NeoTheme.textTertiary,
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            SectionHeader(
              title: _lastQuery.isEmpty
                  ? 'Recherche'
                  : 'Resultats pour "$_lastQuery"',
              subtitle: _lastQuery.isEmpty
                  ? 'Lancez une recherche pour explorer rapidement le catalogue.'
                  : '${filteredResults.length} contenu${filteredResults.length > 1 ? 's' : ''} affiches',
              icon: Icons.manage_search_rounded,
              padding: NeoTheme.screenPadding(context),
            ),
            if (_results.isNotEmpty) ...[
              const SizedBox(height: 12),
              SizedBox(
                height: 44,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: NeoTheme.screenPadding(context),
                  children: [
                    _buildFilterChip('Tous', 'all', _results.length),
                    const SizedBox(width: 8),
                    _buildFilterChip('Films', 'film', filmCount),
                    const SizedBox(width: 8),
                    _buildFilterChip('Séries', 'serie', serieCount),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 12),
            Expanded(
              child: _isLoading
                  ? const Center(
                      child: CircularProgressIndicator(
                        color: NeoTheme.primaryRed,
                      ),
                    )
                  : filteredResults.isEmpty
                  ? _buildEmptyState(context)
                  : (useGrid || NeoTheme.isTV(context))
                  ? GridView.builder(
                      padding: EdgeInsets.fromLTRB(
                        NeoTheme.screenPadding(context).left,
                        0,
                        NeoTheme.screenPadding(context).right,
                        100,
                      ),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: NeoTheme.isTV(context) ? 3 : 2,
                        childAspectRatio: NeoTheme.isTV(context) ? 0.65 : 2.5,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                      ),
                      itemCount: filteredResults.length,
                      itemBuilder: (context, index) {
                        final content = filteredResults[index];
                        return ContentCard(
                          content: content,
                          variant: NeoTheme.isTV(context)
                              ? CardVariant.standard
                              : CardVariant.search,
                          index: index,
                          onTap: () => _navigateToDetail(content),
                        );
                      },
                    )
                  : ListView.builder(
                      padding: EdgeInsets.fromLTRB(
                        NeoTheme.screenPadding(context).left,
                        0,
                        NeoTheme.screenPadding(context).right,
                        100,
                      ),
                      itemCount: filteredResults.length,
                      itemBuilder: (context, index) {
                        final content = filteredResults[index];
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: ContentCard(
                            content: content,
                            variant: CardVariant.search,
                            index: index,
                            onTap: () => _navigateToDetail(content),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChip(String label, String type, int count) {
    final selected = _filterType == type;

    return Focus(
      child: Builder(
        builder: (context) {
          final isFocused = Focus.of(context).hasFocus;
          return ChoiceChip(
            label: Text('$label ($count)'),
            selected: selected,
            onSelected: (_) => setState(() => _filterType = type),
            selectedColor: NeoTheme.primaryRed,
            backgroundColor: isFocused
                ? NeoTheme.primaryRed.withValues(alpha: 0.3)
                : NeoTheme.bgElevated,
            labelStyle: NeoTheme.labelMedium(context).copyWith(
              color: selected || isFocused
                  ? Colors.white
                  : NeoTheme.textSecondary,
            ),
            side: BorderSide(
              color: isFocused
                  ? Colors.white
                  : (selected
                        ? NeoTheme.primaryRed
                        : NeoTheme.bgBorder.withValues(alpha: 0.3)),
              width: isFocused ? 2 : 1,
            ),
            showCheckmark: false,
          );
        },
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    final hasQuery = _lastQuery.isNotEmpty;

    return Center(
      child: Padding(
        padding: NeoTheme.screenPadding(context),
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: NeoTheme.panelDecoration(elevated: true),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                hasQuery
                    ? Icons.search_off_rounded
                    : Icons.travel_explore_rounded,
                size: 64,
                color: NeoTheme.textDisabled,
              ),
              const SizedBox(height: 18),
              Text(
                hasQuery
                    ? (_errorMessage != null
                          ? 'Recherche indisponible'
                          : 'Aucun resultat pour "$_lastQuery"')
                    : 'Rechercher un film ou une serie',
                style: NeoTheme.titleLarge(context),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                _errorMessage ??
                    (hasQuery
                        ? 'Essayez une autre orthographe ou un mot-cle plus large.'
                        : 'Exemple: thriller, animation, serie coreenne...'),
                style: NeoTheme.bodyMedium(context),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
