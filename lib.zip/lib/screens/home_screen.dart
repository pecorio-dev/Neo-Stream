import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config/theme.dart';
import '../models/content.dart';
import '../providers/providers.dart';
import '../widgets/content_card.dart';
import '../widgets/hero_banner.dart';
import '../widgets/section_header.dart';
import '../widgets/shimmer_loading.dart';
import 'browse_screen.dart';
import 'detail_screen.dart';
import 'profile_screen.dart';
import 'search_screen.dart';
import 'ai_search_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  int _currentIndex = 0;
  late final ScrollController _scrollController;
  late final AnimationController _fadeController;
  double _appBarOpacity = 0;

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController()..addListener(_onScroll);
    _fadeController = AnimationController(
      vsync: this,
      duration: NeoTheme.durationSlow,
    )..forward();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ContentProvider>().loadHome();
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  void _onScroll() {
    final offset = _scrollController.offset;
    final nextOpacity = (offset / 220).clamp(0.0, 1.0);
    if ((nextOpacity - _appBarOpacity).abs() < 0.03) {
      return;
    }
    setState(() {
      _appBarOpacity = nextOpacity;
    });
  }

  void _navigateToDetail(Content content) {
    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (_, animation, _) => DetailScreen(contentId: content.id),
        transitionDuration: const Duration(milliseconds: 250),
        reverseTransitionDuration: const Duration(milliseconds: 200),
        transitionsBuilder: (_, animation, secondaryAnimation, child) {
          final curve = CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
            reverseCurve: Curves.easeInCubic,
          );
          return FadeTransition(
            opacity: curve,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0.05, 0),
                end: Offset.zero,
              ).animate(curve),
              child: child,
            ),
          );
        },
      ),
    );
  }

  int _gridColumns(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    if (width >= 1200) return 6;
    if (width >= 900) return 5;
    if (width >= 600) return 4;
    return 2;
  }

  double _gridChildAspect(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    if (width >= 1200) return 0.64;
    if (width >= 900) return 0.62;
    if (width >= 600) return 0.6;
    return 0.62;
  }

  Widget _buildScreenForIndex(int index) {
    switch (index) {
      case 1:
        return const BrowseScreen();
      case 2:
        return const SearchScreen();
      case 3:
        return const AiSearchScreen();
      case 4:
        return const ProfileScreen();
      case 0:
      default:
        return _buildHomeContent();
    }
  }

  List<Content> _showcaseItems(ContentProvider content) {
    final items = <Content>[
      ...content.hero,
      ...content.dailyTop,
      ...content.recommended,
      ...content.popularFilms,
      ...content.popularSeries,
      ...content.recentFilms,
      ...content.recentSeries,
    ];

    final seen = <int>{};
    return items.where((item) => seen.add(item.id)).toList();
  }

  double _averageRating(List<Content> items) {
    final rated = items.where((item) => item.rating > 0).toList();
    if (rated.isEmpty) {
      return 0;
    }
    final total = rated.fold<double>(0, (sum, item) => sum + item.rating);
    return total / rated.length;
  }

  @override
  Widget build(BuildContext context) {
    final isTV = NeoTheme.isTV(context);
    final shellContent = AnimatedSwitcher(
      duration: NeoTheme.durationNormal,
      switchInCurve: NeoTheme.smoothOut,
      switchOutCurve: Curves.easeIn,
      child: KeyedSubtree(
        key: ValueKey<int>(_currentIndex),
        child: _buildScreenForIndex(_currentIndex),
      ),
    );

    return Scaffold(
      backgroundColor: NeoTheme.bgBase,
      extendBodyBehindAppBar: !isTV,
      body: isTV
          ? Row(
              // Removed SafeArea here, let CustomScrollView handle it or let it go full screen
              children: [
                _buildTVNavigationRail(context),
                Expanded(
                  child: ClipRect(
                    // Added ClipRect to prevent content bleeding over rail
                    child: shellContent,
                  ),
                ),
              ],
            )
          : shellContent,
      bottomNavigationBar: isTV
          ? null
          : Container(
              decoration: BoxDecoration(
                gradient: NeoTheme.topPanelGradient,
                border: Border(
                  top: BorderSide(
                    color: NeoTheme.bgBorder.withValues(alpha: 0.25),
                  ),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.3),
                    blurRadius: 20,
                    offset: const Offset(0, -4),
                  ),
                ],
              ),
              child: Theme(
                data: Theme.of(context).copyWith(
                  splashColor: Colors.transparent,
                  highlightColor: Colors.transparent,
                ),
                child: BottomNavigationBar(
                  currentIndex: _currentIndex,
                  onTap: (index) {
                    if (index != _currentIndex) {
                      setState(() => _currentIndex = index);
                    }
                  },
                  type: BottomNavigationBarType.fixed,
                  backgroundColor: Colors.transparent,
                  elevation: 0,
                  selectedItemColor: NeoTheme.primaryRed,
                  unselectedItemColor: NeoTheme.textTertiary,
                  selectedFontSize: 12,
                  unselectedFontSize: 12,
                  selectedLabelStyle: const TextStyle(
                    fontWeight: FontWeight.w700,
                  ),
                  items: [
                    _buildNavItem(
                      Icons.home_outlined,
                      Icons.home_rounded,
                      'Accueil',
                      0,
                    ),
                    _buildNavItem(
                      Icons.grid_view_rounded,
                      Icons.grid_view,
                      'Catalogue',
                      1,
                    ),
                    _buildNavItem(
                      Icons.search_rounded,
                      Icons.manage_search_rounded,
                      'Recherche',
                      2,
                    ),
                    _buildNavItem(
                      Icons.auto_awesome_outlined,
                      Icons.auto_awesome_rounded,
                      'Assistant IA',
                      3,
                    ),
                    _buildNavItem(
                      Icons.person_outline_rounded,
                      Icons.person_rounded,
                      'Profil',
                      4,
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  BottomNavigationBarItem _buildNavItem(
    IconData icon,
    IconData activeIcon,
    String label,
    int index,
  ) {
    final isSelected = _currentIndex == index;
    return BottomNavigationBarItem(
      icon: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOutCubic,
        padding: EdgeInsets.only(bottom: isSelected ? 4.0 : 0.0),
        child: Icon(isSelected ? activeIcon : icon, size: isSelected ? 26 : 24),
      ),
      label: label,
    );
  }

  Widget _buildTVNavigationRail(BuildContext context) {
    final content = context.watch<ContentProvider>();

    return Container(
      width: NeoTheme.tvRailWidth(context),
      decoration: BoxDecoration(
        gradient: NeoTheme.topPanelGradient,
        border: Border(
          right: BorderSide(color: NeoTheme.bgBorder.withValues(alpha: 0.28)),
        ),
      ),
      child: NavigationRail(
        selectedIndex: _currentIndex,
        extended: false,
        labelType: NavigationRailLabelType.all,
        onDestinationSelected: (index) => setState(() => _currentIndex = index),
        leading: Padding(
          padding: const EdgeInsets.only(top: 18),
          child: Column(
            children: [
              Container(
                width: 62,
                height: 62,
                decoration: BoxDecoration(
                  gradient: NeoTheme.heroGradient,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Icon(
                  Icons.play_circle_fill_rounded,
                  color: Colors.white,
                  size: 28,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'NEO',
                style: NeoTheme.labelLarge(context).copyWith(
                  color: NeoTheme.primaryRed,
                  fontWeight: FontWeight.w900,
                ),
              ),
              Text(
                'STREAM',
                style: NeoTheme.labelSmall(
                  context,
                ).copyWith(color: NeoTheme.textPrimary, letterSpacing: 1.4),
              ),
            ],
          ),
        ),
        trailing: Padding(
          padding: const EdgeInsets.only(top: 20),
          child: Container(
            width: 70,
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
            decoration: NeoTheme.panelDecoration(
              accent: content.isPremium
                  ? NeoTheme.prestigeGold
                  : NeoTheme.infoCyan,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  content.isPremium
                      ? Icons.workspace_premium_rounded
                      : Icons.verified_user_outlined,
                  size: 18,
                  color: content.isPremium
                      ? NeoTheme.prestigeGold
                      : NeoTheme.infoCyan,
                ),
                const SizedBox(height: 6),
                Text(
                  content.isPremium ? 'Premium' : 'Standard',
                  textAlign: TextAlign.center,
                  style: NeoTheme.labelSmall(context).copyWith(
                    color: content.isPremium
                        ? NeoTheme.prestigeGold
                        : NeoTheme.infoCyan,
                  ),
                ),
              ],
            ),
          ),
        ),
        destinations: const [
          NavigationRailDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: Text('Accueil'),
          ),
          NavigationRailDestination(
            icon: Icon(Icons.grid_view_rounded),
            selectedIcon: Icon(Icons.grid_view),
            label: Text('Catalogue'),
          ),
          NavigationRailDestination(
            icon: Icon(Icons.search_rounded),
            selectedIcon: Icon(Icons.manage_search_rounded),
            label: Text('Recherche'),
          ),
          NavigationRailDestination(
            icon: Icon(Icons.auto_awesome_outlined),
            selectedIcon: Icon(Icons.auto_awesome_rounded),
            label: Text('Assistant IA'),
          ),
          NavigationRailDestination(
            icon: Icon(Icons.person_outline_rounded),
            selectedIcon: Icon(Icons.person_rounded),
            label: Text('Profil'),
          ),
        ],
      ),
    );
  }

  Widget _buildHomeContent() {
    final content = context.watch<ContentProvider>();
    final showcaseItems = _showcaseItems(content);
    final averageRating = _averageRating(showcaseItems);
    final spotlightAdditions = content.addedToday.take(6).toList();
    final recommendedItems = content.recommended.take(10).toList();
    final popularFilms = content.popularFilms.take(12).toList();
    final popularSeries = content.popularSeries.take(12).toList();

    if (content.isLoadingHome) {
      return const ShimmerHomeLoading();
    }

    if (content.homeError != null) {
      return Center(
        child: Padding(
          padding: NeoTheme.screenPadding(context),
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: NeoTheme.panelDecoration(
              accent: NeoTheme.errorRed,
              elevated: true,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.cloud_off_rounded,
                  size: 64,
                  color: NeoTheme.errorRed.withValues(alpha: 0.78),
                ),
                const SizedBox(height: 18),
                Text(
                  'Erreur de chargement',
                  style: NeoTheme.titleLarge(context),
                ),
                const SizedBox(height: 8),
                Text(
                  content.homeError!,
                  style: NeoTheme.bodyMedium(context),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
                ElevatedButton.icon(
                  onPressed: () => content.loadHome(),
                  icon: const Icon(Icons.refresh_rounded),
                  label: const Text('Reessayer'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return FadeTransition(
      opacity: _fadeController,
      child: SafeArea(
        top: !NeoTheme.isTV(
          context,
        ), // Let TV go full screen behind the transparent app bar
        child: RefreshIndicator(
          onRefresh: () => content.loadHome(),
          color: NeoTheme.primaryRed,
          backgroundColor: NeoTheme.bgElevated,
          child: CustomScrollView(
            controller: _scrollController,
            slivers: [
              SliverAppBar(
                floating: true,
                snap: true,
                elevation: 0,
                backgroundColor: NeoTheme.bgBase.withValues(
                  alpha: _appBarOpacity,
                ),
                title: AnimatedOpacity(
                  opacity: _appBarOpacity,
                  duration: NeoTheme.durationFast,
                  child: Row(
                    children: [
                      Text(
                        'NEO',
                        style: NeoTheme.titleLarge(context).copyWith(
                          color: NeoTheme.primaryRed,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        'STREAM',
                        style: NeoTheme.titleLarge(context).copyWith(
                          color: NeoTheme.textPrimary,
                          fontWeight: FontWeight.w300,
                          letterSpacing: 2.8,
                        ),
                      ),
                    ],
                  ),
                ),
                actions: [
                  Padding(
                    padding: const EdgeInsets.only(right: 12),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      decoration: NeoTheme.panelDecoration(
                        accent: content.isPremium
                            ? NeoTheme.prestigeGold
                            : NeoTheme.bgBorder,
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            content.isPremium
                                ? Icons.workspace_premium_rounded
                                : Icons.lock_open_rounded,
                            size: 16,
                            color: content.isPremium
                                ? NeoTheme.prestigeGold
                                : NeoTheme.textSecondary,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            content.isPremium ? 'Premium' : 'Standard',
                            style: NeoTheme.labelMedium(context).copyWith(
                              color: content.isPremium
                                  ? NeoTheme.prestigeGold
                                  : NeoTheme.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              if (content.hero.isNotEmpty)
                SliverToBoxAdapter(
                  child: HeroBanner(
                    items: content.hero,
                    onTap: _navigateToDetail,
                  ),
                ),
              SliverToBoxAdapter(
                child: _buildOverviewRail(
                  totalAvailable: content.totalAvailable,
                  isPremium: content.isPremium,
                  continueCount: content.continueWatching.length,
                  totalFilms: content.totalFilms,
                  totalSeries: content.totalSeries,
                  averageRating: averageRating,
                ),
              ),
              if (content.continueWatching.isNotEmpty)
                _buildHorizontalSection(
                  'Continuer a regarder',
                  'Reprenez exactement ou vous vous etes arrete.',
                  content.continueWatching,
                  cardVariant: CardVariant.continueWatching,
                  height: 150,
                  icon: Icons.play_circle_outline_rounded,
                ),
              if (content.dailyTop.isNotEmpty)
                _buildHorizontalSection(
                  'Top 10 du jour',
                  'Les contenus qui font le plus parler aujourd hui.',
                  content.dailyTop,
                  cardVariant: CardVariant.dailyTop,
                  height: NeoTheme.cardHeight(context) + 28,
                  icon: Icons.local_fire_department_outlined,
                ),
              if (recommendedItems.isNotEmpty)
                _buildHorizontalSection(
                  'Notre selection',
                  'Des choix simples et pertinents pour lancer vite.',
                  recommendedItems,
                  cardVariant: CardVariant.recommendation,
                  icon: Icons.auto_awesome_outlined,
                ),
              if (spotlightAdditions.isNotEmpty)
                ..._buildGridSlivers(
                  'Nouveautes',
                  'Les derniers ajouts mis en avant sur Neo-Stream.',
                  spotlightAdditions,
                  icon: Icons.fiber_new_outlined,
                ),
              if (popularFilms.isNotEmpty)
                _buildHorizontalSection(
                  'Films populaires',
                  'Une selection cinema claire et immediate.',
                  popularFilms,
                  icon: Icons.movie_filter_outlined,
                ),
              if (popularSeries.isNotEmpty)
                _buildHorizontalSection(
                  'Series tendance',
                  'Les series qui meritent un vrai coup d oeil.',
                  popularSeries,
                  icon: Icons.tv_outlined,
                ),
              const SliverToBoxAdapter(
                child: SizedBox(height: 40),
              ), // Reduced from 110 for TV
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOverviewRail({
    required int totalAvailable,
    required bool isPremium,
    required int continueCount,
    required int totalFilms,
    required int totalSeries,
    required double averageRating,
  }) {
    final cards = [
      {
        'label': 'Catalogue',
        'value': totalAvailable > 0
            ? '$totalAvailable titres'
            : 'Toujours a jour',
        'icon': Icons.grid_view_rounded,
        'color': NeoTheme.primaryRed,
      },
      {
        'label': 'Films et series',
        'value': totalFilms > 0 || totalSeries > 0
            ? '$totalFilms films / $totalSeries series'
            : 'Catalogue complet',
        'icon': Icons.movie_filter_outlined,
        'color': NeoTheme.textPrimary, // Changed to white for 2-color scheme
      },
      {
        'label': isPremium ? 'Premium' : 'En ce moment',
        'value': averageRating > 0
            ? 'Note ${averageRating.toStringAsFixed(1)}'
            : '$continueCount en cours',
        'icon': isPremium
            ? Icons.workspace_premium_rounded
            : Icons.local_fire_department_outlined,
        'color': isPremium
            ? NeoTheme.prestigeGold
            : NeoTheme
                  .primaryRed, // Changed to red for 2-color scheme (except premium gold)
      },
    ];

    return Padding(
      padding: EdgeInsets.fromLTRB(
        NeoTheme.screenPadding(context).left,
        16,
        NeoTheme.screenPadding(context).right,
        0,
      ),
      child: SizedBox(
        height: 88,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: cards.length,
          separatorBuilder: (_, _) => const SizedBox(width: 12),
          itemBuilder: (context, index) {
            final card = cards[index];
            return Container(
              width: NeoTheme.isTV(context) ? 238 : 208,
              padding: const EdgeInsets.all(14),
              decoration: NeoTheme.panelDecoration(
                accent: card['color'] as Color,
                elevated: true,
              ),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: NeoTheme.pillDecoration(
                      color: (card['color'] as Color).withValues(alpha: 0.18),
                    ),
                    child: Icon(
                      card['icon'] as IconData,
                      color: card['color'] as Color,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          card['label'] as String,
                          style: NeoTheme.labelSmall(context),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          card['value'] as String,
                          style: NeoTheme.titleMedium(context),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  SliverToBoxAdapter _buildHorizontalSection(
    String title,
    String subtitle,
    List<Content> items, {
    required IconData icon,
    CardVariant cardVariant = CardVariant.standard,
    double? height,
  }) {
    final visibleItems = items.take(12).toList();

    return SliverToBoxAdapter(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: NeoTheme.sectionGap(context)),
          SectionHeader(title: title, subtitle: subtitle, icon: icon),
          const SizedBox(height: 14),
          SizedBox(
            height: height ?? NeoTheme.cardHeight(context),
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: NeoTheme.screenPadding(context),
              itemCount: visibleItems.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: ContentCard(
                    content: visibleItems[index],
                    variant: cardVariant,
                    index: index,
                    onTap: () => _navigateToDetail(visibleItems[index]),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _buildGridSlivers(
    String title,
    String subtitle,
    List<Content> items, {
    required IconData icon,
  }) {
    final visibleItems = items.take(6).toList();

    return [
      SliverToBoxAdapter(child: SizedBox(height: NeoTheme.sectionGap(context))),
      SliverToBoxAdapter(
        child: SectionHeader(title: title, subtitle: subtitle, icon: icon),
      ),
      const SliverToBoxAdapter(child: SizedBox(height: 14)),
      SliverPadding(
        padding: NeoTheme.screenPadding(context),
        sliver: SliverGrid(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: _gridColumns(context),
            childAspectRatio: _gridChildAspect(context),
            crossAxisSpacing: 12,
            mainAxisSpacing: 14,
          ),
          delegate: SliverChildBuilderDelegate(
            (context, index) => ContentCard(
              content: visibleItems[index],
              index: index,
              onTap: () => _navigateToDetail(visibleItems[index]),
            ),
            childCount: visibleItems.length,
          ),
        ),
      ),
    ];
  }
}
