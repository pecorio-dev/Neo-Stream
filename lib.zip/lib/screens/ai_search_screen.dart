import 'package:flutter/material.dart';

import '../config/theme.dart';
import '../models/content.dart';
import '../services/api_service.dart';
import '../widgets/content_card.dart';
import '../widgets/section_header.dart';
import 'detail_screen.dart';

class AiSearchScreen extends StatefulWidget {
  const AiSearchScreen({super.key});

  @override
  State<AiSearchScreen> createState() => _AiSearchScreenState();
}

class _AiSearchScreenState extends State<AiSearchScreen> {
  final ApiService _api = ApiService();
  final TextEditingController _customController = TextEditingController();

  String _selectedFormat = '';
  String _selectedVibe = '';
  String _selectedWant = '';
  String _selectedExclude = '';
  String _selectedDecade = '';

  bool _isLoading = false;
  String? _errorMessage;
  String? _assistantMessage;
  List<Content> _results = [];
  List<String> _suggestedQuestions = [];

  final List<String> _formats = [
    '',
    'Un film',
    'Une série',
    'Un manga / anime',
    'Un documentaire'
  ];
  final List<String> _vibes = [
    '',
    'Sombre et oppressant',
    'Léger et drôle',
    'Épique et grandiose',
    'Émouvant et triste',
    'Réfléchi et mystérieux',
    'Rythmé et plein d\'action',
    'Effrayant et tendu'
  ];
  final List<String> _wants = [
    '',
    'du voyage dans le temps',
    'des super-héros puissants',
    'des enquêtes policières',
    'de la haute technologie / hacking',
    'un univers post-apocalyptique',
    'des créatures magiques ou surnaturelles',
    'une bataille spatiale épique',
  ];
  final List<String> _excludes = [
    '',
    'les films très anciens',
    'la violence extrême et le gore',
    'les histoires d\'amour romantiques',
    'les productions peu connues (navets)',
    'la politique complexe'
  ];
  final List<String> _decades = [
    '',
    'Classique (avant 2000)',
    'Les années 2000',
    'Récent (après 2010)',
    'Très récent (après 2020)'
  ];

  @override
  void dispose() {
    _customController.dispose();
    super.dispose();
  }

  Future<void> _performAiSearch([String? directQuery]) async {
    FocusScope.of(context).unfocus();

    String finalPrompt = directQuery ?? "";
    if (finalPrompt.isEmpty) {
      if (_selectedFormat.isNotEmpty) finalPrompt += "Je recherche particulièrement: $_selectedFormat. ";
      if (_selectedVibe.isNotEmpty) finalPrompt += "Ambiance souhaitée: $_selectedVibe. ";
      if (_selectedDecade.isNotEmpty) finalPrompt += "De l'époque: $_selectedDecade. ";
      if (_selectedWant.isNotEmpty) finalPrompt += "Je veux qu'il y ait $_selectedWant. ";
      if (_selectedExclude.isNotEmpty) finalPrompt += "Je déteste et je ne veux surtout pas: $_selectedExclude. ";
      
      if (_customController.text.trim().isNotEmpty) {
        finalPrompt += "Précisions supplémentaires: ${_customController.text.trim()}";
      }
    }

    if (finalPrompt.trim().isEmpty) {
      setState(() {
        _errorMessage = "Veuillez choisir un critère ou écrire une demande.";
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _assistantMessage = null;
      _results = [];
      _suggestedQuestions = [];
    });

    try {
      final response = await _api.aiSearchContent(finalPrompt);
      if (response['error'] != null) {
        throw Exception(response['error']);
      }

      final aiAnalysis = response['ai_analysis'] as Map<String, dynamic>?;
      final resultsJson = response['results'] as List<dynamic>?;
      
      if (aiAnalysis == null) {
        throw Exception("L'API n'a pas renvoyé le bon format. Avez-vous uploadé index.php et ai_assistant.php sur le serveur en ligne neo-stream.eu ?");
      }
      
      setState(() {
        _assistantMessage = aiAnalysis['assistant_message']?.toString() ?? "Voici ce que j'ai trouvé.";
        
        final suggested = aiAnalysis['suggested_questions'];
        if (suggested is List) {
          _suggestedQuestions = List<String>.from(suggested.map((e) => e.toString()));
        } else {
          _suggestedQuestions = [];
        }

        if (resultsJson != null && resultsJson.isNotEmpty) {
          _results = resultsJson.whereType<Map<String, dynamic>>().map((e) => Content.fromJson(e)).toList();
        }
        _isLoading = false;
      });
    } catch (error) {
      setState(() {
        _isLoading = false;
        _errorMessage = "Erreur IA: ${error.toString().replaceAll('Exception: ', '')}";
      });
    }
  }

  void _navigateToDetail(Content content) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => DetailScreen(contentId: content.id)),
    );
  }

  Widget _buildDropdown(String label, String value, List<String> items, ValueChanged<String?> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: NeoTheme.labelMedium(context)),
        const SizedBox(height: 6),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: NeoTheme.panelDecoration(),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              isExpanded: true,
              dropdownColor: NeoTheme.bgElevated,
              value: value,
              style: NeoTheme.bodyMedium(context).copyWith(color: NeoTheme.textPrimary),
              icon: const Icon(Icons.arrow_drop_down_rounded, color: NeoTheme.primaryRed),
              items: items.map((String item) {
                return DropdownMenuItem<String>(
                  value: item,
                  child: Text(item.isEmpty ? "Peu importe" : item),
                );
              }).toList(),
              onChanged: onChanged,
            ),
          ),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final useGrid = MediaQuery.of(context).size.width >= 900;
    final isTV = NeoTheme.isTV(context);

    // Filter results if needed, though they are already from DB list
    
    return Scaffold(
      backgroundColor: NeoTheme.bgBase,
      body: SafeArea(
        top: !isTV,
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(
                NeoTheme.screenPadding(context).left,
                16,
                NeoTheme.screenPadding(context).right,
                0,
              ),
              child: SectionHeader(
                title: 'Assistant IA',
                subtitle: 'Trouvez exactement ce que vous cherchez avec l\'IA.',
                icon: Icons.auto_awesome_rounded,
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: CustomScrollView(
                slivers: [
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: NeoTheme.screenPadding(context),
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: NeoTheme.panelDecoration(elevated: true),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildDropdown(
                              "1. Type de format ?",
                              _selectedFormat,
                              _formats,
                              (val) => setState(() => _selectedFormat = val ?? ''),
                            ),
                            _buildDropdown(
                              "2. Ambiance générale ?",
                              _selectedVibe,
                              _vibes,
                              (val) => setState(() => _selectedVibe = val ?? ''),
                            ),
                            _buildDropdown(
                              "3. Un élément que je VEUX voir :",
                              _selectedWant,
                              _wants,
                              (val) => setState(() => _selectedWant = val ?? ''),
                            ),
                            _buildDropdown(
                              "4. Époque / Période de sortie :",
                              _selectedDecade,
                              _decades,
                              (val) => setState(() => _selectedDecade = val ?? ''),
                            ),
                            _buildDropdown(
                              "5. À EXCLURE absolument :",
                              _selectedExclude,
                              _excludes,
                              (val) => setState(() => _selectedExclude = val ?? ''),
                            ),
                            Text("6. Et pour aller plus vite, écrivez vos envies :", style: NeoTheme.labelMedium(context)),
                            const SizedBox(height: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12),
                              decoration: NeoTheme.panelDecoration(),
                              child: TextField(
                                controller: _customController,
                                style: NeoTheme.bodyMedium(context).copyWith(color: NeoTheme.textPrimary),
                                maxLines: 2,
                                decoration: InputDecoration(
                                  hintText: "Exemple: Un film des années 90 qui se passe sur Mars...",
                                  hintStyle: NeoTheme.bodyMedium(context).copyWith(color: NeoTheme.textDisabled),
                                  border: InputBorder.none,
                                ),
                              ),
                            ),
                            const SizedBox(height: 24),
                            SizedBox(
                              width: double.infinity,
                              height: 48,
                              child: ElevatedButton.icon(
                                onPressed: _isLoading ? null : () => _performAiSearch(),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: NeoTheme.primaryRed,
                                  foregroundColor: Colors.white,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                                icon: _isLoading 
                                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                                    : const Icon(Icons.manage_search_rounded),
                                label: Text(
                                  _isLoading ? 'Recherche en cours...' : 'Demander à l\'IA',
                                  style: const TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  if (_errorMessage != null)
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: NeoTheme.screenPadding(context),
                        child: Text(
                          _errorMessage!,
                          style: TextStyle(color: NeoTheme.errorRed, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),

                  if (_assistantMessage != null)
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: EdgeInsets.fromLTRB(
                          NeoTheme.screenPadding(context).left,
                          12,
                          NeoTheme.screenPadding(context).right,
                          12,
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Icon(Icons.psychology_rounded, color: NeoTheme.infoCyan, size: 28),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                _assistantMessage!,
                                style: NeoTheme.bodyLarge(context).copyWith(fontStyle: FontStyle.italic),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                  if (_suggestedQuestions.isNotEmpty)
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: NeoTheme.screenPadding(context),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 8),
                            Text("Suggestions pour affiner :", style: NeoTheme.labelMedium(context)),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: _suggestedQuestions.map<Widget>((q) => ActionChip(
                                label: Text(q),
                                backgroundColor: NeoTheme.bgElevated,
                                labelStyle: NeoTheme.bodySmall(context).copyWith(color: NeoTheme.infoCyan),
                                side: BorderSide(color: NeoTheme.infoCyan.withValues(alpha: 0.3)),
                                onPressed: () {
                                  _customController.text = q;
                                  _performAiSearch(q);
                                },
                                avatar: const Icon(Icons.auto_awesome, size: 14, color: NeoTheme.infoCyan),
                              )).toList(),
                            )
                          ],
                        ),
                      ),
                    ),

                  if (_results.isNotEmpty)
                    SliverPadding(
                      padding: EdgeInsets.fromLTRB(
                        NeoTheme.screenPadding(context).left,
                        16,
                        NeoTheme.screenPadding(context).right,
                        100,
                      ),
                      sliver: SliverList(
                        delegate: SliverChildBuilderDelegate(
                          (context, index) {
                            final content = _results[index];
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 12),
                              child: ContentCard(
                                content: content,
                                variant: CardVariant.search,
                                index: index,
                                onTap: () => _navigateToDetail(content),
                              ),
                            );
                          },
                          childCount: _results.length,
                        ),
                      ),
                    ),
                    
                  if (!_isLoading && _results.isEmpty && _assistantMessage != null)
                     const SliverToBoxAdapter(
                        child: SizedBox(height: 100),
                     ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
