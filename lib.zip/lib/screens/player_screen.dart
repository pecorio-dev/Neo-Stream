import 'dart:async';
import 'dart:collection';

import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../config/theme.dart';
import '../models/content.dart';
import '../services/api_service.dart';
import '../utils/watch_link_utils.dart';

class PlayerScreen extends StatefulWidget {
  final Content content;
  final String videoSourceUrl;
  final List<WatchLink> candidateServers;
  final String? preferredLanguage;
  final String? episodeId;

  const PlayerScreen({
    super.key,
    required this.content,
    required this.videoSourceUrl,
    required this.candidateServers,
    this.preferredLanguage,
    this.episodeId,
  });

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  final ApiService _api = ApiService();

  VideoPlayerController? _videoController;
  ChewieController? _chewieController;
  bool _isExtracting = true;
  bool _isInitializing = false;
  String? _error;
  String? _serverName;

  Timer? _progressTimer;
  double _lastSavedTime = 0;

  bool _showControls = true;
  Timer? _controlsTimer;
  final FocusNode _playerFocusNode = FocusNode();

  int _currentServerIndex = 0;
  List<WatchLink> _availableServers = <WatchLink>[];
  final List<HeadlessInAppWebView> _activeWebViews = <HeadlessInAppWebView>[];
  int _extractionSessionId = 0;
  int _parallelism = 1;
  int _testedServerCount = 0;
  String? _lastFailureReason;

  @override
  void initState() {
    super.initState();
    
    WakelockPlus.enable();

    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    _availableServers = WatchLinkUtils.prioritize(
      widget.candidateServers.isNotEmpty
          ? widget.candidateServers
          : widget.content.watchLinks,
      preferredLanguage: widget.preferredLanguage,
    );
    _parallelism = WatchLinkUtils.recommendedParallelism();

    _startExtractionPipeline();
  }

  @override
  void dispose() {
    _saveProgress();
    _cancelExtractionSession();
    
    WakelockPlus.disable();

    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    _progressTimer?.cancel();
    _controlsTimer?.cancel();
    _videoController?.dispose();
    _chewieController?.dispose();
    _playerFocusNode.dispose();
    super.dispose();
  }

  Future<void> _startExtractionPipeline({int startIndex = 0}) async {
    if (_availableServers.isEmpty || startIndex >= _availableServers.length) {
      if (!mounted) {
        return;
      }
      setState(() {
        _isExtracting = false;
        _isInitializing = false;
        _error =
            _lastFailureReason ??
            'Aucune source lisible n a pu etre extraite automatiquement.';
      });
      return;
    }

    _cancelExtractionSession();
    final sessionId = ++_extractionSessionId;

    setState(() {
      _isExtracting = true;
      _isInitializing = false;
      _error = null;
      _testedServerCount = startIndex;
      _serverName = WatchLinkUtils.sourceLabel(_availableServers[startIndex]);
      _lastFailureReason = null;
    });

    final result = await _extractFirstSuccessful(
      sessionId: sessionId,
      startIndex: startIndex,
    );

    if (!mounted || sessionId != _extractionSessionId) {
      return;
    }

    if (result == null) {
      setState(() {
        _isExtracting = false;
        _isInitializing = false;
        _serverName = null;
        _error =
            _lastFailureReason ??
            'Aucune source lisible n a pu etre extraite automatiquement.';
      });
      return;
    }

    _currentServerIndex = result.index;
    _startPlayerAfterExtraction(
      result.videoUrl,
      result.videoType,
      result.source,
    );
  }

  Future<_ExtractionResult?> _extractFirstSuccessful({
    required int sessionId,
    required int startIndex,
  }) async {
    final queue = Queue<_ServerCandidate>.from(
      List<_ServerCandidate>.generate(_availableServers.length - startIndex, (
        offset,
      ) {
        final index = startIndex + offset;
        return _ServerCandidate(index: index, source: _availableServers[index]);
      }),
    );

    final completer = Completer<_ExtractionResult?>();
    var activeWorkers = 0;
    var finished = false;

    void complete(_ExtractionResult? result) {
      if (finished || completer.isCompleted) {
        return;
      }
      finished = true;
      _disposeActiveWebViews();
      completer.complete(result);
    }

    void maybeLaunchNext() {
      while (!finished &&
          activeWorkers < _parallelism &&
          queue.isNotEmpty &&
          sessionId == _extractionSessionId) {
        final candidate = queue.removeFirst();
        activeWorkers++;
        _markCandidateStarted(candidate);

        _extractFromServer(candidate, sessionId)
            .then((result) {
              activeWorkers--;

              if (finished || sessionId != _extractionSessionId) {
                return;
              }

              if (result != null) {
                complete(result);
                return;
              }

              if (queue.isEmpty && activeWorkers == 0) {
                complete(null);
                return;
              }

              maybeLaunchNext();
            })
            .catchError((_) {
              activeWorkers--;
              if (finished || sessionId != _extractionSessionId) {
                return;
              }

              if (queue.isEmpty && activeWorkers == 0) {
                complete(null);
                return;
              }

              maybeLaunchNext();
            });
      }

      if (!finished && queue.isEmpty && activeWorkers == 0) {
        complete(null);
      }
    }

    maybeLaunchNext();
    return completer.future;
  }

  void _markCandidateStarted(_ServerCandidate candidate) {
    if (!mounted) {
      return;
    }
    setState(() {
      _testedServerCount = candidate.index + 1;
      _serverName = WatchLinkUtils.sourceLabel(candidate.source);
    });
  }

  Future<_ExtractionResult?> _extractFromServer(
    _ServerCandidate candidate,
    int sessionId,
  ) async {
    final completer = Completer<_ExtractionResult?>();
    HeadlessInAppWebView? webView;
    Timer? timeout;
    var resolved = false;

    void resolve(_ExtractionResult? result, {String? failureReason}) {
      if (resolved) {
        return;
      }
      resolved = true;
      timeout?.cancel();
      if (failureReason != null && failureReason.trim().isNotEmpty) {
        _lastFailureReason = failureReason;
      }
      if (webView != null) {
        _activeWebViews.remove(webView);
        webView.dispose();
      }
      if (!completer.isCompleted) {
        completer.complete(result);
      }
    }

    bool maybeResolveWithPlayableUrl(String? rawUrl) {
      final normalized = _normalizePlayableUrl(rawUrl);
      if (normalized == null) {
        return false;
      }
      resolve(
        _ExtractionResult(
          index: candidate.index,
          source: candidate.source,
          videoUrl: normalized,
          videoType: _inferVideoType(normalized),
        ),
      );
      return true;
    }

    try {
      final sourceUrl = candidate.source.url;

      webView = HeadlessInAppWebView(
        initialUrlRequest: URLRequest(url: WebUri(sourceUrl)),
        initialSettings: InAppWebViewSettings(
          useShouldInterceptRequest: true,
          useShouldInterceptFetchRequest: true,
          useShouldInterceptAjaxRequest: true,
          javaScriptEnabled: true,
          mediaPlaybackRequiresUserGesture: false,
          javaScriptCanOpenWindowsAutomatically: true,
          supportMultipleWindows: false,
          userAgent:
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        ),
        initialUserScripts: UnmodifiableListView<UserScript>([
          UserScript(
            source: '''
              try {
                Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
                delete window.flutter_inappwebview;
              } catch (_) {}
            ''',
            injectionTime: UserScriptInjectionTime.AT_DOCUMENT_START,
            forMainFrameOnly: false,
          ),
        ]),
        shouldOverrideUrlLoading: (controller, navigationAction) async {
          if (resolved || sessionId != _extractionSessionId) {
            return NavigationActionPolicy.CANCEL;
          }

          final url = navigationAction.request.url.toString();
          if (maybeResolveWithPlayableUrl(url)) {
            return NavigationActionPolicy.CANCEL;
          }
          return NavigationActionPolicy.ALLOW;
        },
        shouldInterceptRequest: (controller, request) async {
          if (resolved || sessionId != _extractionSessionId) {
            return null;
          }
          maybeResolveWithPlayableUrl(request.url.toString());
          return null;
        },
        shouldInterceptFetchRequest: (controller, request) async {
          if (resolved || sessionId != _extractionSessionId) {
            return null;
          }
          maybeResolveWithPlayableUrl(request.url.toString());
          return null;
        },
        shouldInterceptAjaxRequest: (controller, request) async {
          if (resolved || sessionId != _extractionSessionId) {
            return null;
          }
          maybeResolveWithPlayableUrl(request.url.toString());
          return null;
        },
        onLoadStop: (controller, url) async {
          if (resolved || sessionId != _extractionSessionId) {
            return;
          }

          try {
            await controller.evaluateJavascript(
              source: '''
                document.querySelectorAll(
                  'video, source, button, .play, #play, .vjs-big-play-button, .clappr-play-button, .jw-video, .jw-state-idle, .plyr__control, [class*="play" i], [id*="play" i]'
                ).forEach((element) => {
                  try { element.click(); } catch (_) {}
                });
                try { document.body.click(); } catch (_) {}
              ''',
            );

            await Future.delayed(const Duration(milliseconds: 900));
            if (resolved) {
              return;
            }

            final directSrc = _sanitizeJavascriptValue(
              await controller.evaluateJavascript(
                source: '''
                  (() => {
                    const video = document.querySelector('video');
                    if (video && video.src && video.src.startsWith('http') && !video.src.includes('blob:')) {
                      return video.src;
                    }
                    const source = document.querySelector('source');
                    if (source && source.src && source.src.startsWith('http') && !source.src.includes('blob:')) {
                      return source.src;
                    }
                    return null;
                  })();
                ''',
              ),
            );

            if (maybeResolveWithPlayableUrl(directSrc)) {
              return;
            }

            final iframeSrc = _sanitizeJavascriptValue(
              await controller.evaluateJavascript(
                source: '''
                  (() => {
                    const iframe = document.querySelector('iframe');
                    if (iframe && iframe.src && iframe.src.startsWith('http')) {
                      return iframe.src;
                    }
                    return null;
                  })();
                ''',
              ),
            );

            if (iframeSrc != null &&
                iframeSrc.isNotEmpty &&
                !_isIgnoredUrl(iframeSrc)) {
              await controller.loadUrl(
                urlRequest: URLRequest(url: WebUri(iframeSrc)),
              );
              return;
            }

            final html = _sanitizeJavascriptValue(
              await controller.evaluateJavascript(
                source: 'document.documentElement.outerHTML',
              ),
            );

            if (html != null && html.isNotEmpty) {
              final match = RegExp(
                r'''(https?://[^\s"'<>]+\.(m3u8|mp4)[^\s"'<>]*)''',
                caseSensitive: false,
              ).firstMatch(html);
              if (match != null &&
                  maybeResolveWithPlayableUrl(match.group(1))) {
                return;
              }
            }

            await controller.evaluateJavascript(
              source: 'document.body.click();',
            );
          } catch (_) {}
        },
      );

      _activeWebViews.add(webView);
      timeout = Timer(
        _timeoutFor(candidate.source),
        () => resolve(
          null,
          failureReason:
              'Extraction impossible depuis ${candidate.source.serverName}.',
        ),
      );

      await webView.run();
    } catch (_) {
      resolve(
        null,
        failureReason:
            'Extraction impossible depuis ${candidate.source.serverName}.',
      );
    }

    return completer.future;
  }

  Duration _timeoutFor(WatchLink source) {
    final domain = WatchLinkUtils.sourceLabel(source).toLowerCase();
    if (domain.contains('kakaflix') ||
        domain.contains('multiup') ||
        domain.contains('kokoflix')) {
      return const Duration(seconds: 18);
    }
    return const Duration(seconds: 14);
  }

  String? _normalizePlayableUrl(String? rawUrl) {
    if (rawUrl == null) {
      return null;
    }

    var url = rawUrl.trim();
    if (url.isEmpty || url == 'null' || url == 'undefined') {
      return null;
    }

    if (url.startsWith('//')) {
      url = 'https:$url';
    }

    if (_isIgnoredUrl(url)) {
      return null;
    }

    final lower = url.toLowerCase();
    final looksPlayable =
        lower.contains('.m3u8') ||
        lower.contains('.mp4') ||
        lower.contains('video/mp4') ||
        lower.contains('master.txt');

    if (!looksPlayable) {
      return null;
    }

    return url;
  }

  String? _sanitizeJavascriptValue(dynamic value) {
    if (value == null) {
      return null;
    }

    var raw = value.toString().trim();
    if (raw.isEmpty || raw == 'null' || raw == 'undefined') {
      return null;
    }

    if ((raw.startsWith('"') && raw.endsWith('"')) ||
        (raw.startsWith("'") && raw.endsWith("'"))) {
      raw = raw.substring(1, raw.length - 1);
    }

    return raw
        .replaceAll(r'\/', '/')
        .replaceAll(r'\u002F', '/')
        .replaceAll('&amp;', '&');
  }

  bool _isIgnoredUrl(String url) {
    final lower = url.toLowerCase();
    return lower.contains('google-analytics') ||
        lower.contains('googlesyndication') ||
        lower.contains('doubleclick') ||
        lower.contains('/ads') ||
        lower.contains('blob:');
  }

  String _inferVideoType(String url) {
    final lower = url.toLowerCase();
    if (lower.contains('.m3u8') || lower.contains('master.txt')) {
      return 'hls';
    }
    return 'mp4';
  }

  void _startPlayerAfterExtraction(String url, String type, WatchLink source) {
    if (!mounted) {
      return;
    }

    setState(() {
      _serverName = source.serverName;
      _isExtracting = false;
      _isInitializing = true;
    });

    _initializePlayer(url, type, source);
  }

  Future<void> _initializePlayer(
    String videoUrl,
    String type,
    WatchLink source,
  ) async {
    try {
      _chewieController?.dispose();
      _videoController?.dispose();

      final sourceUri = Uri.tryParse(source.url);
      final origin = sourceUri == null || sourceUri.host.isEmpty
          ? ''
          : '${sourceUri.scheme}://${sourceUri.host}';

      _videoController = VideoPlayerController.networkUrl(
        Uri.parse(videoUrl),
        httpHeaders: {
          'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          if (origin.isNotEmpty) 'Referer': '$origin/',
        },
      );

      await _videoController!.initialize();
      await _restoreProgress();

      _chewieController = ChewieController(
        videoPlayerController: _videoController!,
        autoPlay: true,
        looping: false,
        allowFullScreen: true,
        allowMuting: true,
        showControls: true,
        showControlsOnInitialize: true,
        hideControlsTimer: const Duration(seconds: 4),
        materialProgressColors: ChewieProgressColors(
          playedColor: NeoTheme.primaryRed,
          handleColor: NeoTheme.primaryRed,
          bufferedColor: NeoTheme.primaryRed.withValues(alpha: 0.3),
          backgroundColor: NeoTheme.bgBorder.withValues(alpha: 0.3),
        ),
        placeholder: Container(
          color: NeoTheme.bgBase,
          child: const Center(
            child: CircularProgressIndicator(color: NeoTheme.primaryRed),
          ),
        ),
        errorBuilder: (context, errorMessage) {
          return _buildErrorOverlay(
            'Lecture interrompue. Essayez une nouvelle extraction.',
          );
        },
      );

      _startProgressTimer();
      _showControlsBriefly();

      if (!mounted) {
        return;
      }
      setState(() {
        _isInitializing = false;
      });
    } catch (_) {
      final nextStartIndex = _currentServerIndex + 1;
      if (nextStartIndex < _availableServers.length) {
        _lastFailureReason =
            'Lecture impossible sur ${source.serverName}, bascule vers la source suivante.';
        await _startExtractionPipeline(startIndex: nextStartIndex);
        return;
      }

      if (!mounted) {
        return;
      }
      setState(() {
        _isInitializing = false;
        _error =
            'Impossible d initialiser le lecteur apres test de toutes les sources disponibles.';
      });
    }
  }

  void _startProgressTimer() {
    _progressTimer?.cancel();
    _progressTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      _saveProgress();
    });
  }

  Future<void> _saveProgress() async {
    if (_videoController == null || !_videoController!.value.isInitialized) {
      return;
    }

    final position = _videoController!.value.position.inSeconds.toDouble();
    final duration = _videoController!.value.duration.inSeconds.toDouble();

    if (duration <= 0 || position <= 0) {
      return;
    }
    if ((position - _lastSavedTime).abs() < 5) {
      return;
    }

    _lastSavedTime = position;

    try {
      await _api.saveProgress(
        contentId: widget.content.id,
        currentTime: position,
        totalDuration: duration,
        episodeId: widget.episodeId,
      );
    } catch (_) {}
  }

  Future<void> _restoreProgress() async {
    try {
      final progress = await _api.getProgress(widget.content.id);
      if (progress == null) {
        return;
      }
      final currentTime = progress['current_time'];
      if (currentTime is num && currentTime > 10) {
        final seekTo = Duration(seconds: (currentTime - 5).toInt());
        await _videoController!.seekTo(seekTo);
      }
    } catch (_) {}
  }

  void _retryFromStart() {
    _videoController?.pause();
    _chewieController?.dispose();
    _videoController?.dispose();
    _chewieController = null;
    _videoController = null;
    _startExtractionPipeline();
  }

  void _cancelExtractionSession() {
    _extractionSessionId++;
    _disposeActiveWebViews();
  }

  void _disposeActiveWebViews() {
    for (final webView in List<HeadlessInAppWebView>.from(_activeWebViews)) {
      webView.dispose();
    }
    _activeWebViews.clear();
  }

  KeyEventResult _handleKeyEvent(FocusNode node, KeyEvent event) {
    if (event is! KeyDownEvent) {
      return KeyEventResult.ignored;
    }

    final controller = _videoController;
    if (controller == null || !controller.value.isInitialized) {
      return KeyEventResult.ignored;
    }

    final key = event.logicalKey;
    final position = controller.value.position;
    final duration = controller.value.duration;

    if (key == LogicalKeyboardKey.enter ||
        key == LogicalKeyboardKey.select ||
        key == LogicalKeyboardKey.space ||
        key == LogicalKeyboardKey.mediaPlayPause) {
      if (controller.value.isPlaying) {
        controller.pause();
      } else {
        controller.play();
      }
      _showControlsBriefly();
      return KeyEventResult.handled;
    }

    if (key == LogicalKeyboardKey.arrowRight ||
        key == LogicalKeyboardKey.mediaFastForward) {
      final newPosition = position + const Duration(seconds: 10);
      controller.seekTo(newPosition > duration ? duration : newPosition);
      _showControlsBriefly();
      return KeyEventResult.handled;
    }

    if (key == LogicalKeyboardKey.arrowLeft ||
        key == LogicalKeyboardKey.mediaRewind) {
      final newPosition = position - const Duration(seconds: 10);
      controller.seekTo(
        newPosition < Duration.zero ? Duration.zero : newPosition,
      );
      _showControlsBriefly();
      return KeyEventResult.handled;
    }

    if (key == LogicalKeyboardKey.arrowUp) {
      final volume = (controller.value.volume + 0.1).clamp(0.0, 1.0);
      controller.setVolume(volume);
      _showControlsBriefly();
      return KeyEventResult.handled;
    }

    if (key == LogicalKeyboardKey.arrowDown) {
      final volume = (controller.value.volume - 0.1).clamp(0.0, 1.0);
      controller.setVolume(volume);
      _showControlsBriefly();
      return KeyEventResult.handled;
    }

    if (key == LogicalKeyboardKey.escape ||
        key == LogicalKeyboardKey.goBack ||
        key == LogicalKeyboardKey.browserBack) {
      _saveProgress();
      Navigator.of(context).pop();
      return KeyEventResult.handled;
    }

    return KeyEventResult.ignored;
  }

  void _showControlsBriefly() {
    setState(() => _showControls = true);
    _controlsTimer?.cancel();
    _controlsTimer = Timer(const Duration(seconds: 4), () {
      if (mounted) {
        setState(() => _showControls = false);
      }
    });
  }

  void _seekForward() {
    if (_videoController == null) {
      return;
    }
    final position =
        _videoController!.value.position + const Duration(seconds: 10);
    final duration = _videoController!.value.duration;
    _videoController!.seekTo(position > duration ? duration : position);
  }

  void _seekBackward() {
    if (_videoController == null) {
      return;
    }
    final position =
        _videoController!.value.position - const Duration(seconds: 10);
    _videoController!.seekTo(
      position < Duration.zero ? Duration.zero : position,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Focus(
        focusNode: _playerFocusNode,
        autofocus: true,
        onKeyEvent: _handleKeyEvent,
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_isExtracting || _isInitializing)
              _buildLoadingOverlay()
            else if (_error != null)
              _buildErrorOverlay(_error!)
            else if (_chewieController != null)
              Listener(
                onPointerDown: (_) => _showControlsBriefly(),
                child: GestureDetector(
                  onDoubleTapDown: (details) {
                    final width = MediaQuery.of(context).size.width;
                    if (details.globalPosition.dx < width / 2) {
                      _seekBackward();
                    } else {
                      _seekForward();
                    }
                  },
                  child: Chewie(controller: _chewieController!),
                ),
              ),
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: IgnorePointer(
                ignoring: !_showControls,
                child: AnimatedOpacity(
                  duration: NeoTheme.durationNormal,
                  opacity: _showControls ? 1.0 : 0.0,
                  child: _buildTopBar(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingOverlay() {
    final tested = _testedServerCount.clamp(0, _availableServers.length);
    final preferredLanguage = widget.preferredLanguage == null
        ? null
        : WatchLinkUtils.labelForLanguage(widget.preferredLanguage!);

    return Container(
      color: NeoTheme.bgBase,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: 56,
                height: 56,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    const CircularProgressIndicator(
                      color: NeoTheme.primaryRed,
                      strokeWidth: 3,
                    ),
                    Icon(
                      _isExtracting ? Icons.cloud_download : Icons.play_arrow,
                      color: NeoTheme.primaryRed,
                      size: 24,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Text(
                _isExtracting
                    ? 'Recherche automatique d une source valide...'
                    : 'Initialisation du lecteur...',
                style: NeoTheme.titleMedium(context),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                widget.content.displayTitle,
                style: NeoTheme.bodyMedium(context),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                'Sources testees : $tested/${_availableServers.length} - Mode intelligent x$_parallelism',
                style: NeoTheme.labelSmall(
                  context,
                ).copyWith(color: NeoTheme.textTertiary),
                textAlign: TextAlign.center,
              ),
              if (preferredLanguage != null) ...[
                const SizedBox(height: 4),
                Text(
                  'Langue prioritaire : $preferredLanguage',
                  style: NeoTheme.labelSmall(
                    context,
                  ).copyWith(color: NeoTheme.textTertiary),
                  textAlign: TextAlign.center,
                ),
              ],
              if (_serverName != null) ...[
                const SizedBox(height: 4),
                Text(
                  'Source en cours : $_serverName',
                  style: NeoTheme.labelSmall(
                    context,
                  ).copyWith(color: NeoTheme.textTertiary),
                  textAlign: TextAlign.center,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildErrorOverlay(String error) {
    return Container(
      color: NeoTheme.bgBase,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.error_outline,
                size: 56,
                color: NeoTheme.errorRed.withValues(alpha: 0.8),
              ),
              const SizedBox(height: 16),
              Text('Lecture indisponible', style: NeoTheme.titleLarge(context)),
              const SizedBox(height: 8),
              Text(
                error,
                style: NeoTheme.bodyMedium(context),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                'Toutes les sources adaptees ont ete essayees automatiquement.',
                style: NeoTheme.labelSmall(
                  context,
                ).copyWith(color: NeoTheme.textTertiary),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              Wrap(
                alignment: WrapAlignment.center,
                spacing: 12,
                runSpacing: 12,
                children: [
                  ElevatedButton.icon(
                    onPressed: _retryFromStart,
                    icon: const Icon(Icons.refresh, size: 18),
                    label: const Text('Relancer'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: NeoTheme.primaryRed,
                    ),
                  ),
                  OutlinedButton.icon(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, size: 18),
                    label: const Text('Retour'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Container(
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 8,
        left: 16,
        right: 16,
        bottom: 8,
      ),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.black.withValues(alpha: 0.8), Colors.transparent],
        ),
      ),
      child: Row(
        children: [
          IconButton(
            icon: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: NeoTheme.bgGlass.withValues(alpha: 0.5),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.arrow_back,
                color: Colors.white,
                size: 20,
              ),
            ),
            onPressed: () {
              _saveProgress();
              Navigator.pop(context);
            },
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  widget.content.displayTitle,
                  style: NeoTheme.titleMedium(context),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                if (widget.episodeId != null)
                  Text(
                    widget.episodeId!,
                    style: NeoTheme.labelSmall(
                      context,
                    ).copyWith(color: NeoTheme.textTertiary),
                  ),
              ],
            ),
          ),
          if (_serverName != null)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: NeoTheme.bgGlass.withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(NeoTheme.radiusXs),
              ),
              child: Text(
                _serverName!,
                style: NeoTheme.labelSmall(
                  context,
                ).copyWith(color: NeoTheme.successGreen),
              ),
            ),
        ],
      ),
    );
  }
}

class _ServerCandidate {
  final int index;
  final WatchLink source;

  const _ServerCandidate({required this.index, required this.source});
}

class _ExtractionResult {
  final int index;
  final WatchLink source;
  final String videoUrl;
  final String videoType;

  const _ExtractionResult({
    required this.index,
    required this.source,
    required this.videoUrl,
    required this.videoType,
  });
}
