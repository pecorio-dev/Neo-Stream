import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../config/theme.dart';
import '../models/content.dart';
import '../services/api_service.dart';
import '../utils/watch_link_utils.dart';
import '../widgets/content_card.dart';
import 'player_screen.dart';

class DetailScreen extends StatefulWidget {
  final int contentId;

  const DetailScreen({super.key, required this.contentId});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  final ApiService _api = ApiService();
  Content? _content;
  bool _isLoading = true;
  String? _error;
  int _selectedSeason = 1;
  String? _selectedLanguage;

  @override
  void initState() {
    super.initState();
    _loadDetail();
  }

  Future<void> _loadDetail() async {
    try {
      final content = await _api.getContentDetail(widget.contentId);
      final seasons = content.seasons.keys.toList()..sort();

      setState(() {
        _content = content;
        _isLoading = false;
        if (seasons.isNotEmpty) {
          _selectedSeason = seasons.first;
        }
        _selectedLanguage = WatchLinkUtils.defaultLanguage(
          content.availableLanguages,
        );
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        backgroundColor: NeoTheme.bgBase,
        body: const Center(
          child: CircularProgressIndicator(color: NeoTheme.primaryRed),
        ),
      );
    }

    if (_error != null || _content == null) {
      return Scaffold(
        backgroundColor: NeoTheme.bgBase,
        appBar: AppBar(backgroundColor: NeoTheme.bgBase),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.error_outline,
                size: 48,
                color: NeoTheme.errorRed,
              ),
              const SizedBox(height: 16),
              Text(
                _error ?? 'Contenu introuvable',
                style: NeoTheme.bodyMedium(context),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              if (_error?.contains('Premium') == true)
                Container(
                  padding: const EdgeInsets.all(16),
                  margin: const EdgeInsets.symmetric(horizontal: 32),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        NeoTheme.prestigeGold.withValues(alpha: 0.1),
                        NeoTheme.bgElevated,
                      ],
                    ),
                    borderRadius: BorderRadius.circular(NeoTheme.radiusMd),
                    border: Border.all(
                      color: NeoTheme.prestigeGold.withValues(alpha: 0.3),
                    ),
                  ),
                  child: Column(
                    children: [
                      const Icon(
                        Icons.workspace_premium,
                        color: NeoTheme.prestigeGold,
                        size: 40,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Contenu Premium',
                        style: NeoTheme.titleLarge(
                          context,
                        ).copyWith(color: NeoTheme.prestigeGold),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Passez Premium pour acceder a plus de 26 000 titres.',
                        style: NeoTheme.bodySmall(context),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Retour'),
              ),
            ],
          ),
        ),
      );
    }

    final content = _content!;
    final seasonNumbers = content.seasons.keys.toList()..sort();
    final selectedSeasonEpisodes =
        content.seasons[_selectedSeason] ?? const <Episode>[];
    final languageSelector = _buildLanguageSelector(context, content);
    final canPlay = _primaryPlayableLinks(content).isNotEmpty;

    return Scaffold(
      backgroundColor: NeoTheme.bgBase,
      body: SafeArea(
        top: !NeoTheme.isTV(
          context,
        ), // Sur TV on prend tout l'écran, sur mobile on respecte l'encoche
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              expandedHeight: 400,
              pinned: true,
              backgroundColor: NeoTheme.bgBase,
              leading: Padding(
                padding: const EdgeInsets.all(8.0),
                child: IconButton(
                  icon: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(
                        alpha: 0.6,
                      ), // Opacité plus forte pour contraste
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.2),
                      ),
                    ),
                    child: const Icon(
                      Icons.arrow_back,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                  onPressed: () => Navigator.pop(context),
                ),
              ),
              flexibleSpace: FlexibleSpaceBar(
                background: Stack(
                  fit: StackFit.expand,
                  children: [
                    if (content.fullPosterUrl.isNotEmpty)
                      CachedNetworkImage(
                        imageUrl: content.fullPosterUrl,
                        fit: BoxFit.cover,
                      ),
                    const DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: NeoTheme.posterFadeGradient,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (content.genres.isNotEmpty)
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: content.genres
                            .map(
                              (genre) => Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: NeoTheme.getGenreColor(
                                    genre,
                                  ).withValues(alpha: 0.2),
                                  borderRadius: BorderRadius.circular(
                                    NeoTheme.radiusXs,
                                  ),
                                  border: Border.all(
                                    color: NeoTheme.getGenreColor(
                                      genre,
                                    ).withValues(alpha: 0.4),
                                  ),
                                ),
                                child: Text(
                                  genre,
                                  style: NeoTheme.labelMedium(context).copyWith(
                                    color: NeoTheme.getGenreColor(genre),
                                  ),
                                ),
                              ),
                            )
                            .toList(),
                      ),
                    const SizedBox(height: 12),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(
                        content.displayTitle,
                        maxLines: 1,
                        style: NeoTheme.displayMedium(context),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 16,
                      runSpacing: 12,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        if (content.rating > 0)
                          Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: const Color(0xE61C1605),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: 0.25),
                                  blurRadius: 8,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                SizedBox(
                                  width: 44,
                                  height: 44,
                                  child: CircularProgressIndicator(
                                    value: content.rating / 10.0,
                                    strokeWidth: 3.5,
                                    backgroundColor: NeoTheme.prestigeGold
                                        .withValues(alpha: 0.15),
                                    valueColor:
                                        const AlwaysStoppedAnimation<Color>(
                                          NeoTheme.prestigeGold,
                                        ),
                                  ),
                                ),
                                Text(
                                  content.rating.toStringAsFixed(1),
                                  style: const TextStyle(
                                    color: NeoTheme.prestigeGold,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        if (content.releaseDate != null)
                          Text(
                            '${content.releaseDate}',
                            style: NeoTheme.bodyMedium(context),
                          ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            border: Border.all(color: NeoTheme.textTertiary),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            content.typeLabel,
                            style: NeoTheme.labelSmall(context),
                          ),
                        ),
                        if (content.isSerie && content.seasonCount > 0)
                          Text(
                            '${content.seasonCount} saison${content.seasonCount > 1 ? 's' : ''} - ${content.episodeCount} episodes',
                            style: NeoTheme.bodySmall(context),
                          ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    if (languageSelector != null) ...[
                      languageSelector,
                      const SizedBox(height: 16),
                    ],
                    if (content.isSerie) ...[
                      Wrap(
                        spacing: 10,
                        runSpacing: 10,
                        children: [
                          _buildStatCard(
                            context,
                            icon: Icons.layers_outlined,
                            label: 'Saisons',
                            value: '${content.seasonCount}',
                          ),
                          _buildStatCard(
                            context,
                            icon: Icons.movie_filter_outlined,
                            label: 'Episodes',
                            value: '${content.episodeCount}',
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                    ],
                    if (content.description != null)
                      Text(
                        content.description!,
                        style: NeoTheme.bodyLarge(context),
                      ),
                    if (!content.isSerie &&
                        content.userProgress != null &&
                        (content.userProgress!['progress_percent'] ?? 0) > 0) ...[
                      const SizedBox(height: 12),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: LinearProgressIndicator(
                          value: (content.userProgress!['progress_percent']
                                      ?.toDouble() ??
                                  0) /
                              100,
                          backgroundColor: Colors.white10,
                          valueColor:
                              const AlwaysStoppedAnimation(NeoTheme.primaryRed),
                          minHeight: 4,
                        ),
                      ),
                    ],
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: AnimatedScale(
                            scale: 1.0,
                            duration: const Duration(milliseconds: 150),
                            child: ElevatedButton.icon(
                              onPressed: canPlay
                                  ? () => _playPrimaryAction(content)
                                  : null,
                              icon: const Icon(Icons.play_arrow),
                              label: Text(
                                content.isSerie
                                    ? 'LANCER LA LECTURE'
                                    : 'REGARDER',
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: NeoTheme.primaryRed,
                                foregroundColor: Colors.white,
                                elevation: 8,
                                shadowColor: NeoTheme.primaryRed.withValues(
                                  alpha: 0.5,
                                ),
                                padding: const EdgeInsets.symmetric(
                                  vertical: 14,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ).copyWith(
                                overlayColor: WidgetStateProperty.all(
                                  Colors.white.withValues(alpha: 0.2),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Container(
                          decoration: BoxDecoration(
                            color: NeoTheme.bgElevated,
                            shape: BoxShape.circle,
                            border: Border.all(color: NeoTheme.bgBorder),
                          ),
                          child: IconButton(
                            onPressed: () async {
                              final messenger = ScaffoldMessenger.of(context);
                              try {
                                if (content.inLibrary) {
                                  await _api.removeFromLibrary(content.id);
                                  if (!mounted) {
                                    return;
                                  }
                                  messenger.showSnackBar(
                                    const SnackBar(
                                      content: Text('Retire de votre liste'),
                                      backgroundColor: NeoTheme.textSecondary,
                                    ),
                                  );
                                } else {
                                  await _api.addToLibrary(content.id);
                                  if (!mounted) {
                                    return;
                                  }
                                  messenger.showSnackBar(
                                    const SnackBar(
                                      content: Text('Ajoute a votre liste'),
                                      backgroundColor: NeoTheme
                                          .primaryRed, // Changed from successGreen
                                    ),
                                  );
                                }
                                if (!mounted) {
                                  return;
                                }
                                setState(() {
                                  content.inLibrary = !content.inLibrary;
                                });
                              } catch (_) {
                                if (!mounted) {
                                  return;
                                }
                                messenger.showSnackBar(
                                  const SnackBar(
                                    content: Text('Erreur'),
                                    backgroundColor: NeoTheme.errorRed,
                                  ),
                                );
                              }
                            },
                            icon: Icon(
                              content.inLibrary ? Icons.check : Icons.add,
                              color: content.inLibrary
                                  ? NeoTheme
                                        .primaryRed // Changed to primaryRed instead of successGreen
                                  : NeoTheme.textPrimary,
                            ),
                            tooltip: content.inLibrary
                                ? 'Dans ma liste'
                                : 'Ajouter a ma liste',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    if (content.isSerie && content.seasons.isNotEmpty) ...[
                      Text('Episodes', style: NeoTheme.titleLarge(context)),
                      const SizedBox(height: 8),
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: seasonNumbers.map((season) {
                            final isSelected = season == _selectedSeason;
                            return Padding(
                              padding: const EdgeInsets.only(right: 8),
                              child: ChoiceChip(
                                selected: isSelected,
                                label: Text('Saison $season'),
                                labelStyle: NeoTheme.labelMedium(context)
                                    .copyWith(
                                      color: isSelected
                                          ? Colors.white
                                          : NeoTheme.textSecondary,
                                    ),
                                selectedColor: NeoTheme.primaryRed,
                                backgroundColor: NeoTheme.bgElevated,
                                side: BorderSide(
                                  color: isSelected
                                      ? NeoTheme.primaryRed
                                      : NeoTheme.bgBorder.withValues(
                                          alpha: 0.4,
                                        ),
                                ),
                                onSelected: (_) =>
                                    setState(() => _selectedSeason = season),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 300),
                        switchInCurve: Curves.easeOut,
                        switchOutCurve: Curves.easeIn,
                        transitionBuilder: (child, animation) {
                          return FadeTransition(
                            opacity: animation,
                            child: SlideTransition(
                              position: Tween<Offset>(
                                begin: const Offset(0, 0.05),
                                end: Offset.zero,
                              ).animate(animation),
                              child: child,
                            ),
                          );
                        },
                        child: Column(
                          key: ValueKey<int>(_selectedSeason),
                          children: selectedSeasonEpisodes
                              .map(
                                (episode) => _buildEpisodeCard(
                                  context,
                                  content,
                                  episode,
                                ),
                              )
                              .toList(),
                        ),
                      ),
                      const SizedBox(height: 24),
                    ],
                    if (content.similar.isNotEmpty) ...[
                      Text(
                        'Vous aimerez aussi',
                        style: NeoTheme.titleLarge(context),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        height: NeoTheme.cardHeight(context),
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: content.similar.length,
                          itemBuilder: (_, index) => Padding(
                            padding: const EdgeInsets.only(right: 12),
                            child: ContentCard(
                              content: content.similar[index],
                              index: index,
                              onTap: () {
                                Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => DetailScreen(
                                      contentId: content.similar[index].id,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                      ),
                    ],
                    const SizedBox(height: 40),
                    if (content.createdAt != null || content.updatedAt != null)
                      Text(
                        'Ajoute : ${content.createdAt?.split(' ').first ?? '-'} - Mis a jour : ${content.updatedAt?.split(' ').first ?? '-'}',
                        style: NeoTheme.labelSmall(context),
                      ),
                    const SizedBox(height: 80),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget? _buildLanguageSelector(BuildContext context, Content content) {
    final languages = WatchLinkUtils.sortLanguages(
      content.availableLanguages.where((language) => language != 'unknown'),
    );
    if (languages.isEmpty) {
      return null;
    }

    final currentLanguage =
        _selectedLanguage ?? WatchLinkUtils.defaultLanguage(languages);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: NeoTheme.bgElevated,
        borderRadius: BorderRadius.circular(NeoTheme.radiusMd),
        border: Border.all(color: NeoTheme.bgBorder.withValues(alpha: 0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Langue prioritaire', style: NeoTheme.titleMedium(context)),
          const SizedBox(height: 6),
          Text(
            'La lecture essaie d abord la langue choisie puis bascule automatiquement vers une autre source si besoin.',
            style: NeoTheme.bodySmall(context),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: languages.map((language) {
              final isSelected = currentLanguage == language;
              return ChoiceChip(
                selected: isSelected,
                label: Text(WatchLinkUtils.labelForLanguage(language)),
                labelStyle: NeoTheme.labelMedium(context).copyWith(
                  color: isSelected ? Colors.white : NeoTheme.textSecondary,
                ),
                selectedColor: NeoTheme.primaryRed,
                backgroundColor: NeoTheme.bgSurface,
                side: BorderSide(
                  color: isSelected
                      ? NeoTheme.primaryRed
                      : NeoTheme.bgBorder.withValues(alpha: 0.35),
                ),
                onSelected: (_) => setState(() => _selectedLanguage = language),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildMergeBanner(BuildContext context, Content content) {
    final bannerLines = <String>[];

    if (content.autoMerged || content.hasDetachedSeasons) {
      bannerLines.add(
        'Les saisons detachees ont ete regroupees automatiquement.',
      );
    }
    if (content.availableSeasons.isNotEmpty) {
      bannerLines.add(
        'Saisons detectees : ${content.availableSeasons.join(', ')}.',
      );
    }
    if (content.missingSeasons.isNotEmpty) {
      bannerLines.add(
        'Saisons manquantes : ${content.missingSeasons.join(', ')}.',
      );
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: NeoTheme.textTertiary.withValues(
          alpha: 0.12,
        ), // Changed from infoCyan
        borderRadius: BorderRadius.circular(NeoTheme.radiusMd),
        border: Border.all(
          color: NeoTheme.textTertiary.withValues(alpha: 0.35),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 2),
            child: Icon(
              Icons.auto_fix_high,
              color: NeoTheme.textSecondary,
            ), // Changed from infoCyan
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Fusion intelligente active',
                  style: NeoTheme.titleMedium(
                    context,
                  ).copyWith(color: NeoTheme.textPrimary),
                ),
                const SizedBox(height: 4),
                Text(
                  bannerLines.join(' '),
                  style: NeoTheme.bodySmall(
                    context,
                  ).copyWith(color: NeoTheme.textSecondary),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(
    BuildContext context, {
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: NeoTheme.bgElevated,
        borderRadius: BorderRadius.circular(NeoTheme.radiusMd),
        border: Border.all(color: NeoTheme.bgBorder.withValues(alpha: 0.35)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 18, color: NeoTheme.primaryRed),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value, style: NeoTheme.titleMedium(context)),
              Text(label, style: NeoTheme.labelSmall(context)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEpisodeCard(
    BuildContext context,
    Content content,
    Episode episode,
  ) {
    final preferredLinks = _rankLinks(episode.watchLinks);
    final isPlayable = preferredLinks.isNotEmpty;
    final availableLanguages = WatchLinkUtils.sortLanguages(
      episode.availableLanguages,
    );

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: NeoTheme.bgElevated,
        borderRadius: BorderRadius.circular(NeoTheme.radiusMd),
        border: Border.all(color: NeoTheme.bgBorder.withValues(alpha: 0.35)),
      ),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: NeoTheme.primaryRed.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'E${episode.episode}',
                  style: NeoTheme.titleMedium(
                    context,
                  ).copyWith(color: NeoTheme.primaryRed),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      episode.title,
                      style: NeoTheme.labelLarge(context),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Text(episode.label, style: NeoTheme.bodySmall(context)),
                    if (availableLanguages.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: availableLanguages.map((language) {
                          final isSelectedLanguage =
                              _selectedLanguage == language;
                          return Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: isSelectedLanguage
                                  ? NeoTheme.primaryRed.withValues(alpha: 0.16)
                                  : NeoTheme.bgSurface,
                              borderRadius: BorderRadius.circular(999),
                              border: Border.all(
                                color: isSelectedLanguage
                                    ? NeoTheme.primaryRed.withValues(alpha: 0.45)
                                    : NeoTheme.bgBorder.withValues(alpha: 0.3),
                              ),
                            ),
                            child: Text(
                              WatchLinkUtils.labelForLanguage(language),
                              style: NeoTheme.labelSmall(context).copyWith(
                                color: isSelectedLanguage
                                    ? NeoTheme.primaryRed
                                    : NeoTheme.textSecondary,
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 12),
              IconButton(
                tooltip: isPlayable
                    ? 'Lire ${episode.label}'
                    : 'Episode indisponible',
                onPressed: isPlayable
                    ? () => _launchPlayer(
                        content,
                        preferredLinks,
                        episodeId: 'S${episode.season}E${episode.episode}',
                      )
                    : null,
                icon: Icon(
                  isPlayable ? Icons.play_circle_fill : Icons.lock_outline,
                  color: isPlayable ? NeoTheme.primaryRed : NeoTheme.textDisabled,
                ),
              ),
            ],
          ),
          if (episode.progressPercent != null && episode.progressPercent! > 0) ...[
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(2),
              child: LinearProgressIndicator(
                value: episode.progressPercent! / 100,
                backgroundColor: Colors.white10,
                valueColor: const AlwaysStoppedAnimation(NeoTheme.primaryRed),
                minHeight: 3,
              ),
            ),
          ],
        ],
      ),
    );
  }

  List<WatchLink> _rankLinks(List<WatchLink> watchLinks) {
    return WatchLinkUtils.prioritize(
      watchLinks,
      preferredLanguage: _selectedLanguage,
    );
  }

  List<WatchLink> _primaryPlayableLinks(Content content) {
    if (content.watchLinks.isNotEmpty) {
      return _rankLinks(content.watchLinks);
    }

    final firstEpisode = _firstPlayableEpisode(content);
    if (firstEpisode == null) {
      return const <WatchLink>[];
    }
    return _rankLinks(firstEpisode.watchLinks);
  }

  void _playPrimaryAction(Content content) {
    final rankedLinks = _rankLinks(content.watchLinks);
    if (rankedLinks.isNotEmpty) {
      _launchPlayer(content, rankedLinks);
      return;
    }

    final firstEpisode = _firstPlayableEpisode(content);
    if (firstEpisode != null) {
      _launchPlayer(
        content,
        _rankLinks(firstEpisode.watchLinks),
        episodeId: 'S${firstEpisode.season}E${firstEpisode.episode}',
      );
    }
  }

  Episode? _firstPlayableEpisode(Content content) {
    final seasons = content.seasons.keys.toList()..sort();
    for (final season in seasons) {
      final episodes = content.seasons[season] ?? const <Episode>[];
      for (final episode in episodes) {
        if (_rankLinks(episode.watchLinks).isNotEmpty) {
          return episode;
        }
      }
    }
    return null;
  }

  void _launchPlayer(
    Content content,
    List<WatchLink> candidateServers, {
    String? episodeId,
  }) {
    if (candidateServers.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Aucune source disponible pour cette lecture.'),
          backgroundColor: NeoTheme.errorRed,
        ),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PlayerScreen(
          content: content,
          videoSourceUrl: candidateServers.first.url,
          candidateServers: candidateServers,
          preferredLanguage: _selectedLanguage,
          episodeId: episodeId,
        ),
      ),
    );
  }
}
