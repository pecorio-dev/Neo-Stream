import 'package:flutter/material.dart';

class NeoTheme {
  NeoTheme._();

  static const Color bgBase = Color(0xFF050508);
  static const Color bgSurface = Color(0xFF0A0A12);
  static const Color bgElevated = Color(0xFF10121B);
  static const Color bgOverlay = Color(0xFF161826);
  static const Color bgGlass = Color(0xCC121420);
  static const Color bgActive = Color(0xFF1C2030);
  static const Color bgHover = Color(0xFF23283C);
  static const Color bgBorder = Color(0xFF2F3650);

  static const Color primaryRed = Color(0xFFE50914);
  static const Color primaryRedHover = Color(0xFFFF2833);
  static const Color primaryRedDark = Color(0xFF8F0C14);
  static const Color prestigeGold = Color(0xFFF4C54F);
  static const Color goldDark = Color(0xFFBE8F18);

  static const Color successGreen = Color(0xFF17C78B);
  static const Color infoCyan = Color(0xFF2EC5E8);
  static const Color warningOrange = Color(0xFFF59E0B);
  static const Color errorRed = Color(0xFFEF4444);
  static const Color purpleAccent = Color(0xFF9B7BFF);
  static const Color indigoAccent = Color(0xFF6884FF);

  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(
    0xFFC4CADB,
  ); // Éclairci pour un meilleur contraste
  static const Color textTertiary = Color(
    0xFFA0A7C0,
  ); // Éclairci (ancien: 0xFF8087A0)
  static const Color textDisabled = Color(
    0xFF707790,
  ); // Éclairci (ancien: 0xFF535A73)

  static const Map<String, Color> genreColors = {
    'Action': Color(0xFFFF2D55),
    'Drame': Color(0xFF5856D6),
    'Comedie': Color(0xFFFFCC00),
    'Horreur': Color(0xFF5E5CE6),
    'Romance': Color(0xFFFF375F),
    'Sci-Fi': Color(0xFF64D2FF),
    'Science-Fiction': Color(0xFF64D2FF),
    'Thriller': Color(0xFFFF9500),
    'Animation': Color(0xFF30B0C7),
    'Documentaire': Color(0xFFAF52DE),
    'Fantastique': Color(0xFF007AFF),
    'Aventure': Color(0xFFFF3B30),
    'Crime': Color(0xFF8E8E93),
    'Guerre': Color(0xFF63472C),
    'Musique': Color(0xFFF111E1),
    'Western': Color(0xFF8B4513),
    'Telefilm': Color(0xFF0071A4),
    'Famille': Color(0xFF34C759),
    'Histoire': Color(0xFFA2845E),
    'Mystere': Color(0xFF5856D6),
  };

  static Color getGenreColor(String genre) {
    return genreColors[genre] ?? purpleAccent;
  }

  static const LinearGradient heroGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFFE50914), Color(0xFFFF6B35)],
  );

  static const LinearGradient premiumGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFFF4C54F), Color(0xFFE9A328)],
  );

  static const LinearGradient auroraGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF1B1F31), Color(0xFF101421), Color(0xFF06070B)],
  );

  static const LinearGradient posterFadeGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Colors.transparent, Color(0xFF050508)],
    stops: [0.38, 1],
  );

  static const LinearGradient cardOverlayGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Colors.transparent, Color(0x91050508), Color(0xF5050508)],
    stops: [0, 0.56, 1],
  );

  static const LinearGradient topPanelGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xD31A1E2D), Color(0xD30A0B12)],
  );

  static const LinearGradient glassGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xB81C1F30), Color(0x99101520)],
  );

  static const double radiusXs = 4;
  static const double radiusSm = 8;
  static const double radiusMd = 12;
  static const double radiusLg = 16;
  static const double radiusXl = 20;

  static const double spaceXs = 4;
  static const double spaceSm = 8;
  static const double spaceMd = 12;
  static const double spaceLg = 16;
  static const double spaceXl = 24;
  static const double space2xl = 32;
  static const double space3xl = 48;
  static const double space4xl = 64;

  static const Curve smoothOut = Curves.easeOutCubic;
  static const Curve smoothIn = Curves.easeInCubic;
  static const Curve bounceOut = Curves.elasticOut;
  static const Curve premium = Cubic(0.25, 0.1, 0.25, 1);

  static const Duration durationFast = Duration(milliseconds: 150);
  static const Duration durationNormal = Duration(milliseconds: 250);
  static const Duration durationSlow = Duration(milliseconds: 400);
  static const Duration durationHero = Duration(milliseconds: 600);
  static const Duration durationSplash = Duration(milliseconds: 800);
  static const Duration staggerDelay = Duration(milliseconds: 50);

  static List<BoxShadow> shadowLevel1 = [
    const BoxShadow(
      color: Color(0x40000000),
      blurRadius: 10,
      offset: Offset(0, 4),
    ),
  ];

  static List<BoxShadow> shadowLevel2 = [
    const BoxShadow(
      color: Color(0x5E000000),
      blurRadius: 20,
      offset: Offset(0, 8),
    ),
  ];

  static List<BoxShadow> shadowLevel3 = [
    const BoxShadow(
      color: Color(0x78000000),
      blurRadius: 30,
      offset: Offset(0, 14),
    ),
  ];

  static List<BoxShadow> shadowGlow = [
    BoxShadow(
      color: primaryRed.withValues(alpha: 0.16),
      blurRadius: 42,
      offset: const Offset(0, 18),
    ),
  ];

  static BoxDecoration cardDecoration = BoxDecoration(
    gradient: const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFF131725), Color(0xFF090B12)],
    ),
    borderRadius: BorderRadius.circular(radiusMd),
    border: Border.all(color: bgBorder.withValues(alpha: 0.32), width: 0.7),
    boxShadow: shadowLevel1,
  );

  static BoxDecoration cardFocusedDecoration = BoxDecoration(
    gradient: const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFF1D2333), Color(0xFF0A0D15)],
    ),
    borderRadius: BorderRadius.circular(radiusMd),
    border: Border.all(color: primaryRed, width: 2),
    boxShadow: [
      BoxShadow(
        color: primaryRed.withValues(alpha: 0.36),
        blurRadius: 18,
        spreadRadius: 1,
      ),
      BoxShadow(
        color: primaryRed.withValues(alpha: 0.12),
        blurRadius: 34,
        spreadRadius: 6,
      ),
    ],
  );

  static BoxDecoration glassDecoration = BoxDecoration(
    gradient: glassGradient,
    borderRadius: BorderRadius.circular(radiusLg),
    border: Border.all(color: bgBorder.withValues(alpha: 0.34), width: 0.6),
    boxShadow: shadowLevel2,
  );

  static BoxDecoration panelDecoration({Color? accent, bool elevated = false}) {
    final edge = accent ?? bgBorder;
    return BoxDecoration(
      gradient: elevated ? topPanelGradient : auroraGradient,
      borderRadius: BorderRadius.circular(radiusLg),
      border: Border.all(
        color: edge.withValues(alpha: accent != null ? 0.48 : 0.34),
        width: 0.8,
      ),
      boxShadow: elevated ? shadowLevel2 : shadowLevel1,
    );
  }

  static BoxDecoration pillDecoration({Color? color, bool selected = false}) {
    final base = color ?? bgElevated;
    return BoxDecoration(
      color: selected ? base : base.withValues(alpha: 0.62),
      borderRadius: BorderRadius.circular(999),
      border: Border.all(
        color: selected
            ? (color ?? primaryRed).withValues(alpha: 0.92)
            : bgBorder.withValues(alpha: 0.28),
        width: 0.8,
      ),
    );
  }

  static bool isTV(BuildContext context) =>
      MediaQuery.of(context).size.width >= 1100;

  static bool isTablet(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return width >= 700 && width < 1100;
  }

  static bool isMobile(BuildContext context) =>
      MediaQuery.of(context).size.width < 700;

  static double scaleFactor(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    if (width >= 1400) return 1.3;
    if (width >= 1100) return 1.18;
    if (width >= 900) return 1.08;
    return 1;
  }

  static int gridColumns(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    if (width >= 1400) return 6;
    if (width >= 1100) return 5;
    if (width >= 900) return 4;
    if (width >= 700) return 3;
    return 2;
  }

  static double cardWidth(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    if (width >= 1400) return 216;
    if (width >= 1100) return 198;
    if (width >= 900) return 174;
    if (width >= 700) return 160;
    return 148;
  }

  static double cardHeight(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    if (width >= 1400) return 354;
    if (width >= 1100) return 330;
    if (width >= 900) return 292;
    if (width >= 700) return 266;
    return 236;
  }

  static double searchCardHeight(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    if (width >= 1100) return 172;
    if (width >= 900) return 164;
    if (width >= 700) return 156;
    return 148;
  }

  static double heroHeight(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    if (width >= 1400) return 660;
    if (width >= 1100) return 600;
    if (width >= 900) return 540;
    if (width >= 700) return 500;
    return 460;
  }

  static double sectionGap(BuildContext context) {
    if (isTV(context)) return 34;
    if (isTablet(context)) return 28;
    return 24;
  }

  static EdgeInsets screenPadding(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    if (width >= 1400) return const EdgeInsets.symmetric(horizontal: 34);
    if (width >= 1100) return const EdgeInsets.symmetric(horizontal: 28);
    if (width >= 900) return const EdgeInsets.symmetric(horizontal: 22);
    return const EdgeInsets.symmetric(horizontal: 16);
  }

  static double tvRailWidth(BuildContext context) => isTV(context) ? 116 : 0;

  static TextStyle _text(
    BuildContext context, {
    required double size,
    required FontWeight weight,
    required Color color,
    double? letterSpacing,
    double? height,
  }) {
    return TextStyle(
      fontSize: size * scaleFactor(context),
      fontWeight: weight,
      color: color,
      letterSpacing: letterSpacing,
      height: height,
    );
  }

  static TextStyle displayLarge(BuildContext context) => _text(
    context,
    size: 34,
    weight: FontWeight.w900,
    color: textPrimary,
    letterSpacing: -1.0,
    height: 1.05,
  );

  static TextStyle displayMedium(BuildContext context) => _text(
    context,
    size: 28,
    weight: FontWeight.w800,
    color: textPrimary,
    letterSpacing: -0.5,
    height: 1.08,
  );

  static TextStyle headlineLarge(BuildContext context) => _text(
    context,
    size: 24,
    weight: FontWeight.w700,
    color: textPrimary,
    letterSpacing: -0.3,
    height: 1.12,
  );

  static TextStyle headlineMedium(BuildContext context) => _text(
    context,
    size: 20,
    weight: FontWeight.w700,
    color: textPrimary,
    height: 1.12,
  );

  static TextStyle titleLarge(BuildContext context) => _text(
    context,
    size: 18,
    weight: FontWeight.w600,
    color: textPrimary,
    letterSpacing: 0.1,
    height: 1.18,
  );

  static TextStyle titleMedium(BuildContext context) => _text(
    context,
    size: 16,
    weight: FontWeight.w600,
    color: textPrimary,
    letterSpacing: 0.1,
    height: 1.2,
  );

  static TextStyle bodyLarge(BuildContext context) => _text(
    context,
    size: 16,
    weight: FontWeight.w400,
    color: textSecondary,
    letterSpacing: 0.15,
    height: 1.35,
  );

  static TextStyle bodyMedium(BuildContext context) => _text(
    context,
    size: 14,
    weight: FontWeight.w400,
    color: textSecondary,
    letterSpacing: 0.15,
    height: 1.38,
  );

  static TextStyle bodySmall(BuildContext context) => _text(
    context,
    size: 12,
    weight: FontWeight.w400,
    color: textTertiary,
    letterSpacing: 0.2,
    height: 1.36,
  );

  static TextStyle labelLarge(BuildContext context) => _text(
    context,
    size: 14,
    weight: FontWeight.w600,
    color: textPrimary,
    letterSpacing: 0.35,
    height: 1.2,
  );

  static TextStyle labelMedium(BuildContext context) => _text(
    context,
    size: 12,
    weight: FontWeight.w600,
    color: textPrimary,
    letterSpacing: 0.45,
    height: 1.18,
  );

  static TextStyle labelSmall(BuildContext context) => _text(
    context,
    size: 10,
    weight: FontWeight.w600,
    color: textTertiary,
    letterSpacing: 0.7,
    height: 1.12,
  );

  static ThemeData get themeData => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: bgBase,
    primaryColor: primaryRed,
    colorScheme: const ColorScheme.dark(
      primary: primaryRed,
      secondary: prestigeGold,
      surface: bgSurface,
      error: errorRed,
      onPrimary: textPrimary,
      onSecondary: Color(0xFF000000),
      onSurface: textPrimary,
      onError: textPrimary,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: false,
      iconTheme: IconThemeData(color: textPrimary),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: bgSurface,
      selectedItemColor: primaryRed,
      unselectedItemColor: textTertiary,
      type: BottomNavigationBarType.fixed,
      elevation: 10,
    ),
    navigationRailTheme: NavigationRailThemeData(
      backgroundColor: bgSurface.withValues(alpha: 0.84),
      selectedIconTheme: const IconThemeData(color: primaryRed),
      unselectedIconTheme: const IconThemeData(color: textTertiary),
      selectedLabelTextStyle: const TextStyle(
        color: textPrimary,
        fontWeight: FontWeight.w700,
      ),
      unselectedLabelTextStyle: const TextStyle(
        color: textTertiary,
        fontWeight: FontWeight.w500,
      ),
      indicatorColor: primaryRed.withValues(alpha: 0.18),
      groupAlignment: -0.7,
    ),
    chipTheme: ChipThemeData(
      backgroundColor: bgElevated,
      disabledColor: bgSurface,
      selectedColor: primaryRed,
      secondarySelectedColor: primaryRed,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      labelStyle: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w600,
        color: textPrimary,
      ),
      secondaryLabelStyle: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w700,
        color: textPrimary,
      ),
      side: BorderSide(color: bgBorder.withValues(alpha: 0.35)),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
    ),
    cardTheme: CardThemeData(
      color: bgSurface,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(radiusMd),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: bgElevated,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(radiusSm),
        borderSide: BorderSide(color: bgBorder.withValues(alpha: 0.5)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(radiusSm),
        borderSide: BorderSide(color: bgBorder.withValues(alpha: 0.5)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(radiusSm),
        borderSide: const BorderSide(color: primaryRed, width: 2),
      ),
      hintStyle: const TextStyle(color: textTertiary, fontSize: 14),
      labelStyle: const TextStyle(color: textSecondary, fontSize: 14),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primaryRed,
        foregroundColor: textPrimary,
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusMd),
        ),
        textStyle: const TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.3,
        ),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: textSecondary,
        side: BorderSide(color: textTertiary.withValues(alpha: 0.52)),
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusMd),
        ),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: infoCyan,
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
      ),
    ),
    progressIndicatorTheme: const ProgressIndicatorThemeData(
      color: primaryRed,
      linearTrackColor: bgElevated,
    ),
    snackBarTheme: SnackBarThemeData(
      backgroundColor: bgOverlay,
      contentTextStyle: const TextStyle(color: textPrimary, fontSize: 14),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(radiusSm),
      ),
      behavior: SnackBarBehavior.floating,
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: bgOverlay,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(radiusLg),
      ),
    ),
    dividerTheme: DividerThemeData(
      color: bgBorder.withValues(alpha: 0.3),
      thickness: 0.5,
      space: 1,
    ),
  );
}
